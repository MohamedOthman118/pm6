"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { BarChart3, CalendarDays, CheckCircle2, ChevronDown, ChevronRight, Clock3, Maximize2, Minimize2, RefreshCw, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import type { Project, Task } from "./model";

const DAY = 86400000;

function dateMs(value: string) {
  return new Date(`${value}T00:00:00Z`).getTime();
}

function addDays(value: string, days: number) {
  return new Date(dateMs(value) + days * DAY).toISOString().slice(0, 10);
}

function formatDate(value: string, options?: Intl.DateTimeFormatOptions) {
  return new Date(`${value}T00:00:00Z`).toLocaleDateString("en-GB", options ?? { day: "numeric", month: "short" });
}

function orderedTasks(tasks: Task[]) {
  const result: Task[] = [];
  const visited = new Set<string>();
  const walk = (task: Task) => {
    if (visited.has(task.id)) return;
    visited.add(task.id);
    result.push(task);
    tasks.filter((child) => child.parentId === task.id).forEach(walk);
  };
  tasks.filter((task) => !task.parentId || !tasks.some((candidate) => candidate.id === task.parentId)).forEach(walk);
  tasks.filter((task) => !visited.has(task.id)).forEach(walk);
  return result;
}

function depthOf(task: Task, tasks: Task[]) {
  let depth = 0;
  let parentId = task.parentId;
  while (parentId && depth < 3) {
    depth += 1;
    parentId = tasks.find((candidate) => candidate.id === parentId)?.parentId ?? null;
  }
  return depth;
}

function bounds(tasks: Task[]) {
  const today = new Date().toISOString().slice(0, 10);
  const earliest = tasks.reduce((min, task) => task.start < min ? task.start : min, tasks[0]?.start ?? today);
  const latest = tasks.reduce((max, task) => task.end > max ? task.end : max, tasks[0]?.end ?? addDays(today, 30));
  return { start: addDays(earliest, -7), end: addDays(latest, 14) };
}

export default function ManagerView({ project, shareId, initialUpdatedAt, onClose }: { project: Project; shareId?: string; initialUpdatedAt?: string; onClose?: () => void }) {
  const [liveProject, setLiveProject] = useState(project);
  const [updatedAt, setUpdatedAt] = useState(initialUpdatedAt);
  const [scale, setScale] = useState<"day" | "week" | "overview">("week");
  const [hideDone, setHideDone] = useState(false);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async (quiet = false) => {
    if (!shareId) return;
    if (!quiet) setRefreshing(true);
    try {
      const response = await fetch(`/api/shares/${shareId}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { project?: Project; updatedAt?: string };
      if (data.project) setLiveProject(data.project);
      if (data.updatedAt) setUpdatedAt(data.updatedAt);
    } finally {
      if (!quiet) setRefreshing(false);
    }
  }, [shareId]);

  useEffect(() => {
    if (!shareId) return;
    const timer = window.setInterval(() => void refresh(true), 15000);
    return () => window.clearInterval(timer);
  }, [shareId, refresh]);

  useEffect(() => {
    const listener = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", listener);
    return () => document.removeEventListener("fullscreenchange", listener);
  }, []);

  const toggleFullscreen = async () => {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await containerRef.current?.requestFullscreen();
  };

  const tasks = useMemo(() => orderedTasks(liveProject.tasks).filter((task) => {
    if (hideDone && task.status === "Done") return false;
    if (task.parentId && collapsed.has(task.parentId)) return false;
    return true;
  }), [liveProject, hideDone, collapsed]);

  const leafTasks = liveProject.tasks.filter((task) => !liveProject.tasks.some((candidate) => candidate.parentId === task.id));
  const progress = Math.round(leafTasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, leafTasks.length));
  const done = leafTasks.filter((task) => task.status === "Done").length;
  const blocked = leafTasks.filter((task) => task.status === "Blocked").length;
  const { start, end } = bounds(liveProject.tasks);
  const totalDays = Math.max(30, Math.ceil((dateMs(end) - dateMs(start)) / DAY) + 1);
  const pxPerDay = scale === "day" ? 42 : scale === "week" ? 14 : 6;
  const tickDays = scale === "day" ? 1 : scale === "week" ? 7 : 30;
  const chartWidth = Math.max(880, totalDays * pxPerDay);
  const labelWidth = 340;
  const rowHeight = 52;
  const today = new Date().toISOString().slice(0, 10);
  const todayX = ((dateMs(today) - dateMs(start)) / DAY) * pxPerDay;
  const ticks = Array.from({ length: Math.ceil(totalDays / tickDays) }, (_, index) => addDays(start, index * tickDays));

  return (
    <div ref={containerRef} className={`${onClose ? "fixed inset-0 z-[70]" : "min-h-screen"} flex flex-col bg-[#f7f8fa] text-[#202124]`}>
      <header className="shrink-0 border-b border-slate-200 bg-white/95 px-5 py-4 text-slate-900 backdrop-blur-xl sm:px-8">
        <div className="flex flex-wrap items-center gap-4">
          <div className="grid size-10 place-items-center rounded-xl bg-[#0073ea] text-white"><BarChart3 className="size-5" /></div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2"><span className="text-[0.68rem] font-bold uppercase tracking-[0.2em] text-slate-400">Manager view</span>{shareId && <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[0.66rem] font-bold text-emerald-700">Live</span>}</div>
            <h1 className="truncate text-xl font-bold tracking-tight sm:text-2xl">{liveProject.name}</h1>
          </div>
          <Select value={scale} onValueChange={(value) => setScale(value as typeof scale)}>
            <SelectTrigger className="w-[132px] bg-white"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="day">Day view</SelectItem><SelectItem value="week">Week view</SelectItem><SelectItem value="overview">Overview</SelectItem></SelectContent>
          </Select>
          <Button variant="outline" onClick={() => setHideDone((value) => !value)} className="bg-white">{hideDone ? "Show completed" : "Hide completed"}</Button>
          {shareId && <Button variant="outline" size="icon" onClick={() => refresh()} disabled={refreshing} className="bg-white" aria-label="Refresh shared project"><RefreshCw className={`size-4 ${refreshing ? "animate-spin" : ""}`} /></Button>}
          <Button variant="outline" onClick={toggleFullscreen} className="gap-2 bg-white">{isFullscreen ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />} <span className="hidden sm:inline">{isFullscreen ? "Exit full screen" : "Full screen"}</span></Button>
          {onClose && <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:bg-slate-100 hover:text-slate-900" aria-label="Close manager view"><X className="size-5" /></Button>}
        </div>
        {shareId && <p className="mt-2 text-xs text-slate-400">Automatically refreshes every 15 seconds{updatedAt ? ` · Updated ${new Date(updatedAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}` : ""}</p>}
      </header>

      <section className="grid shrink-0 grid-cols-2 gap-3 border-b border-slate-200 bg-white px-5 py-4 sm:grid-cols-4 sm:px-8">
        <Metric icon={<BarChart3 className="size-4" />} label="Progress" value={`${progress}%`} color={liveProject.color} />
        <Metric icon={<CheckCircle2 className="size-4" />} label="Completed" value={`${done}/${leafTasks.length}`} color="#0f9f80" />
        <Metric icon={<Clock3 className="size-4" />} label="Blocked" value={String(blocked)} color="#f26b38" />
        <Metric icon={<CalendarDays className="size-4" />} label="Schedule" value={liveProject.tasks.length ? `${formatDate(liveProject.tasks.reduce((min, task) => task.start < min ? task.start : min, liveProject.tasks[0].start))} – ${formatDate(liveProject.tasks.reduce((max, task) => task.end > max ? task.end : max, liveProject.tasks[0].end), { day: "numeric", month: "short", year: "numeric" })}` : "No dates"} color="#367bf5" compact />
      </section>

      <section className="min-h-0 flex-1 overflow-auto bg-white">
        <div className="relative" style={{ width: labelWidth + chartWidth, minHeight: 70 + Math.max(1, tasks.length) * rowHeight }}>
          <div className="sticky top-0 z-30 flex h-[70px] border-b border-slate-200 bg-white" style={{ width: labelWidth + chartWidth }}>
            <div className="sticky left-0 z-40 flex w-[340px] shrink-0 items-center border-r border-slate-200 bg-slate-50 px-5 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Workstream / task</div>
            <div className="relative flex" style={{ width: chartWidth }}>
              {ticks.map((tick, index) => {
                const tickWidth = tickDays * pxPerDay;
                const isWeekend = scale === "day" && [5, 6].includes(new Date(`${tick}T00:00:00Z`).getUTCDay());
                return <div key={tick} className={`relative shrink-0 border-r border-slate-200 px-2 pt-9 text-xs ${isWeekend ? "bg-slate-100 text-slate-400" : "bg-white text-slate-500"}`} style={{ width: tickWidth }}><span className="font-semibold">{scale === "day" ? formatDate(tick, { day: "numeric" }) : formatDate(tick)}</span>{(scale !== "day" || new Date(`${tick}T00:00:00Z`).getUTCDate() === 1 || index === 0) && <span className="absolute left-2 top-2 whitespace-nowrap text-[0.68rem] font-bold uppercase tracking-[0.1em] text-slate-700">{scale === "overview" ? formatDate(tick, { month: "long", year: "numeric" }) : formatDate(tick, { month: "short", year: "numeric" })}</span>}</div>;
              })}
            </div>
          </div>

          <div className="relative flex" style={{ width: labelWidth + chartWidth, height: Math.max(1, tasks.length) * rowHeight }}>
            <div className="sticky left-0 z-20 w-[340px] shrink-0 border-r border-slate-200 bg-white shadow-[8px_0_20px_rgba(31,41,55,.04)]">
              {tasks.map((task) => {
                const hasChildren = liveProject.tasks.some((candidate) => candidate.parentId === task.id);
                const depth = depthOf(task, liveProject.tasks);
                return <div key={task.id} className="flex items-center border-b border-slate-100 px-4" style={{ height: rowHeight }}><div className="flex min-w-0 flex-1 items-center" style={{ paddingLeft: depth * 20 }}>{hasChildren ? <button type="button" onClick={() => setCollapsed((current) => { const next = new Set(current); if (next.has(task.id)) next.delete(task.id); else next.add(task.id); return next; })} className="mr-1 rounded p-1 text-slate-400 hover:bg-slate-100">{collapsed.has(task.id) ? <ChevronRight className="size-4" /> : <ChevronDown className="size-4" />}</button> : <span className="mr-2 w-4" />}<span className="mr-2.5 size-2.5 shrink-0 rounded-full" style={{ backgroundColor: task.color }} /><span className="min-w-0"><span className={`block truncate text-sm ${hasChildren ? "font-bold" : "font-medium"}`}>{task.name}</span><span className="block truncate text-[0.7rem] text-slate-400">{task.owner} · {task.progress}%</span></span></div></div>;
              })}
            </div>
            <div className="relative" style={{ width: chartWidth, height: Math.max(1, tasks.length) * rowHeight, backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${tickDays * pxPerDay - 1}px, #e6eaf0 ${tickDays * pxPerDay - 1}px, #e6eaf0 ${tickDays * pxPerDay}px), repeating-linear-gradient(to bottom, transparent 0, transparent ${rowHeight - 1}px, #eef1f5 ${rowHeight - 1}px, #eef1f5 ${rowHeight}px)` }}>
              {todayX >= 0 && todayX <= chartWidth && <div className="absolute inset-y-0 z-[3] w-0.5 bg-red-400" style={{ left: todayX }}><span className="absolute -top-6 -translate-x-1/2 rounded bg-red-500 px-2 py-0.5 text-[0.65rem] font-bold uppercase tracking-wide text-white">Today</span></div>}
              {tasks.map((task, index) => {
                const left = ((dateMs(task.start) - dateMs(start)) / DAY) * pxPerDay;
                const width = Math.max(22, (((dateMs(task.end) - dateMs(task.start)) / DAY) + 1) * pxPerDay);
                const hasChildren = liveProject.tasks.some((candidate) => candidate.parentId === task.id);
                return <div key={task.id} className="absolute z-[2]" style={{ left, top: index * rowHeight + (hasChildren ? 13 : 11), width, height: hasChildren ? 25 : 30 }}><div className={`${hasChildren ? "rounded-md" : "rounded-lg"} absolute inset-0 overflow-hidden shadow-sm`} style={{ backgroundColor: task.color }}><div className="absolute inset-y-0 left-0 bg-black/15" style={{ width: `${task.progress}%` }} /><span className="relative block truncate px-2.5 py-1 text-xs font-bold text-white drop-shadow-sm">{task.name}</span></div>{width < 105 && <span className="absolute left-[calc(100%+8px)] top-1 whitespace-nowrap text-xs font-semibold text-slate-700">{task.name}</span>}</div>;
              })}
              {!tasks.length && <div className="absolute inset-0 grid place-items-center text-sm text-slate-400">All completed tasks are hidden.</div>}
            </div>
          </div>
        </div>
      </section>
      <footer className="flex shrink-0 items-center justify-between border-t border-slate-200 bg-white px-5 py-2.5 text-xs text-slate-500 sm:px-8"><span>Weekend days: Friday and Saturday.</span><span className="hidden sm:inline">Darker bar fill represents completed progress.</span></footer>
    </div>
  );
}

function Metric({ icon, label, value, color, compact }: { icon: React.ReactNode; label: string; value: string; color: string; compact?: boolean }) {
  return <div className="flex min-w-0 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${color}18`, color }}>{icon}</span><span className="min-w-0"><span className="block text-[0.68rem] font-bold uppercase tracking-[0.1em] text-slate-400">{label}</span><span className={`block truncate font-bold ${compact ? "text-sm" : "text-lg"}`}>{value}</span></span>{label === "Progress" && <Progress value={Number.parseInt(value)} className="hidden h-1.5 w-24 xl:block" />}</div>;
}
