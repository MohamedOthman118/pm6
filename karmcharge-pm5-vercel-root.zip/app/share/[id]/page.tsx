import { notFound } from "next/navigation";

import { getStoredShare } from "../../../lib/vercel-blob-store";
import ManagerView from "../../manager-view";

export const dynamic = "force-dynamic";

export default async function SharedProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const shared = await getStoredShare(id);
  if (!shared) notFound();

  return (
    <ManagerView
      project={shared.project}
      shareId={id}
      initialUpdatedAt={shared.updatedAt}
    />
  );
}
