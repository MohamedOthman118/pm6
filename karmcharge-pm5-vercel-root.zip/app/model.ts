export type Priority = "Critical" | "High" | "Medium" | "Low";
export type TaskStatus = "Not started" | "In progress" | "Blocked" | "Done";
export type CustomColumnType = "text" | "number" | "select" | "date" | "checkbox";
export type CustomFieldValue = string | number | boolean;
export type DashboardWidgetId = "progress" | "status" | "priority" | "owners" | "deadlines";

export type TeamMember = {
  id: string;
  name: string;
  role: string;
  avatarUrl?: string;
  color: string;
};

export type CustomColumn = {
  id: string;
  name: string;
  type: CustomColumnType;
  options?: string[];
};

export type Task = {
  id: string;
  name: string;
  parentId: string | null;
  start: string;
  end: string;
  status: TaskStatus;
  priority: Priority;
  progress: number;
  owner: string;
  supportedBy?: string[];
  dependencies: string[];
  color: string;
  notes: string;
  customFields?: Record<string, CustomFieldValue>;
};

export type Project = {
  id: string;
  name: string;
  description: string;
  color: string;
  createdAt: string;
  shareId?: string;
  shareToken?: string;
  team?: TeamMember[];
  customColumns?: CustomColumn[];
  dashboardWidgets?: DashboardWidgetId[];
  tasks: Task[];
};

export const palette = ["#0073ea", "#0f9f80", "#f26b38", "#d14b8f", "#367bf5", "#e0a100"];
export const defaultDashboardWidgets: DashboardWidgetId[] = ["progress", "status", "priority", "owners", "deadlines"];

const makeTask = (task: Task) => task;

export const starterProjects: Project[] = [
  {
    id: "district-5-phase-3",
    name: "District 5 Phase 3",
    description: "AC and DC charger rollout across D5 Mall and Residential.",
    color: "#0073ea",
    createdAt: "2026-09-03T09:00:00.000Z",
    tasks: [
      makeTask({ id: "T-100", name: "Site readiness", parentId: null, start: "2026-09-07", end: "2026-09-18", status: "In progress", priority: "Critical", progress: 58, owner: "Operations", dependencies: [], color: "#0073ea", notes: "Confirm panels, cable routes, and civil scope." }),
      makeTask({ id: "T-101", name: "Complete technical surveys", parentId: "T-100", start: "2026-09-07", end: "2026-09-10", status: "Done", priority: "High", progress: 100, owner: "Technical", dependencies: [], color: "#367bf5", notes: "D5M and D5R surveys." }),
      makeTask({ id: "T-102", name: "Approve final BOQ", parentId: "T-100", start: "2026-09-11", end: "2026-09-18", status: "In progress", priority: "Critical", progress: 35, owner: "Business Dev", dependencies: ["T-101"], color: "#f26b38", notes: "Include charger, meter, signage, and installation scope." }),
      makeTask({ id: "T-200", name: "Meter procurement", parentId: null, start: "2026-09-14", end: "2026-10-09", status: "In progress", priority: "Critical", progress: 28, owner: "Procurement", dependencies: ["T-100"], color: "#f26b38", notes: "Secure meters ahead of installation window." }),
      makeTask({ id: "T-201", name: "Issue supplier purchase order", parentId: "T-200", start: "2026-09-14", end: "2026-09-17", status: "In progress", priority: "Critical", progress: 60, owner: "Procurement", dependencies: ["T-102"], color: "#f26b38", notes: "Confirm quantity, price, warranty, and SLA." }),
      makeTask({ id: "T-202", name: "Receive and inspect meters", parentId: "T-200", start: "2026-09-28", end: "2026-10-09", status: "Not started", priority: "High", progress: 0, owner: "Warehouse", dependencies: ["T-201"], color: "#e0a100", notes: "Record serial numbers and acceptance results." }),
      makeTask({ id: "T-300", name: "Installation & commissioning", parentId: null, start: "2026-10-05", end: "2026-10-23", status: "Not started", priority: "High", progress: 0, owner: "Technical", dependencies: ["T-200"], color: "#0f9f80", notes: "Install, energize, test, and hand over." }),
      makeTask({ id: "T-301", name: "Install chargers and meters", parentId: "T-300", start: "2026-10-05", end: "2026-10-16", status: "Not started", priority: "High", progress: 0, owner: "Contractor", dependencies: ["T-202"], color: "#0f9f80", notes: "Coordinate shutdowns with Marakez." }),
      makeTask({ id: "T-302", name: "Commission payment flow", parentId: "T-300", start: "2026-10-19", end: "2026-10-23", status: "Not started", priority: "High", progress: 0, owner: "Product", dependencies: ["T-301"], color: "#d14b8f", notes: "Test QR journey, receipts, and remote monitoring." }),
      makeTask({ id: "T-400", name: "Launch readiness", parentId: null, start: "2026-10-19", end: "2026-10-30", status: "Not started", priority: "Medium", progress: 0, owner: "Marketing", dependencies: ["T-300"], color: "#d14b8f", notes: "Prepare the site for customer launch." }),
      makeTask({ id: "T-401", name: "Install signage and stickers", parentId: "T-400", start: "2026-10-19", end: "2026-10-26", status: "Not started", priority: "Medium", progress: 0, owner: "Marketing", dependencies: ["T-301"], color: "#d14b8f", notes: "Parking boards, payment instructions, and wayfinding." }),
      makeTask({ id: "T-402", name: "Complete launch checklist", parentId: "T-400", start: "2026-10-27", end: "2026-10-30", status: "Not started", priority: "High", progress: 0, owner: "Project Lead", dependencies: ["T-302", "T-401"], color: "#0073ea", notes: "Final operational and customer-experience sign-off." }),
    ],
  },
  {
    id: "ev-hub-concept",
    name: "EV Hub Concept",
    description: "Concept and business-case development for the first full-scale hub.",
    color: "#0f9f80",
    createdAt: "2026-09-03T09:00:00.000Z",
    tasks: [
      makeTask({ id: "H-100", name: "Concept definition", parentId: null, start: "2026-09-07", end: "2026-09-25", status: "In progress", priority: "High", progress: 45, owner: "Strategy", dependencies: [], color: "#0f9f80", notes: "Define customer promise and operating model." }),
      makeTask({ id: "H-101", name: "Map driver journey", parentId: "H-100", start: "2026-09-07", end: "2026-09-14", status: "Done", priority: "High", progress: 100, owner: "Marketing", dependencies: [], color: "#367bf5", notes: "Arrival through departure." }),
      makeTask({ id: "H-102", name: "Define tenant mix", parentId: "H-100", start: "2026-09-15", end: "2026-09-25", status: "In progress", priority: "Medium", progress: 25, owner: "Commercial", dependencies: ["H-101"], color: "#0f9f80", notes: "Cafe, retail, and vehicle services." }),
      makeTask({ id: "H-200", name: "Design brief", parentId: null, start: "2026-09-21", end: "2026-10-16", status: "Not started", priority: "High", progress: 0, owner: "Marketing", dependencies: ["H-100"], color: "#f26b38", notes: "Translate the experience into a clear agency brief." }),
      makeTask({ id: "H-201", name: "Create spatial requirements", parentId: "H-200", start: "2026-09-21", end: "2026-10-02", status: "Not started", priority: "High", progress: 0, owner: "Technical", dependencies: ["H-102"], color: "#f26b38", notes: "Capacity, circulation, utilities, and operations." }),
      makeTask({ id: "H-202", name: "Finalize creative direction", parentId: "H-200", start: "2026-10-05", end: "2026-10-16", status: "Not started", priority: "Medium", progress: 0, owner: "Brand", dependencies: ["H-201"], color: "#d14b8f", notes: "Retrofuturist beacon and Egyptian visual cues." }),
    ],
  },
];

export const emptyProject = (name: string, color = palette[0]): Project => {
  const now = new Date();
  const start = now.toISOString().slice(0, 10);
  const endDate = new Date(now.getTime() + 7 * 86400000);
  const id = `project-${Date.now()}`;
  const parentId = `T-${String(Date.now()).slice(-5)}`;
  return {
    id,
    name,
    description: "New project workspace",
    color,
    createdAt: now.toISOString(),
    tasks: [
      {
        id: parentId,
        name: "First workstream",
        parentId: null,
        start,
        end: endDate.toISOString().slice(0, 10),
        status: "Not started",
        priority: "Medium",
        progress: 0,
        owner: "Unassigned",
        dependencies: [],
        color,
        notes: "",
      },
      {
        id: `${parentId}-1`,
        name: "First subtask",
        parentId,
        start,
        end: endDate.toISOString().slice(0, 10),
        status: "Not started",
        priority: "Medium",
        progress: 0,
        owner: "Unassigned",
        dependencies: [],
        color,
        notes: "",
      },
    ],
  };
};

export const priorityOrder: Priority[] = ["Critical", "High", "Medium", "Low"];
export const statusOrder: TaskStatus[] = ["Not started", "In progress", "Blocked", "Done"];

export function uid(prefix = "T") {
  return `${prefix}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

export function daysBetween(start: string, end: string) {
  const a = new Date(`${start}T00:00:00Z`).getTime();
  const b = new Date(`${end}T00:00:00Z`).getTime();
  return Math.max(1, Math.round((b - a) / 86400000) + 1);
}

export function safeFileName(value: string) {
  return value.trim().replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "project";
}
