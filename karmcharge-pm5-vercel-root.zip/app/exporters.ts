import type { Project } from "./model";
import { daysBetween, safeFileName } from "./model";

const taskHeaders = [
  "Project",
  "Task ID",
  "Task",
  "Parent Task ID",
  "Start Date",
  "End Date",
  "Status",
  "Priority",
  "Progress %",
  "Owner",
  "Supported by",
  "Dependency IDs",
  "Color",
  "Notes",
];

export async function downloadExcelTemplate() {
  const XLSX = await import("xlsx");
  const workbook = XLSX.utils.book_new();
  const projects = XLSX.utils.aoa_to_sheet([
    ["Project", "Description", "Color"],
    ["Example Project", "Replace this example with your project", "#0073ea"],
  ]);
  const tasks = XLSX.utils.aoa_to_sheet([
    taskHeaders,
    ["Example Project", "T-100", "Planning", "", "2026-09-07", "2026-09-18", "In progress", "High", 40, "Project Lead", "Operations", "", "#0073ea", "Top-level workstream"],
    ["Example Project", "T-101", "Confirm scope", "T-100", "2026-09-07", "2026-09-10", "Done", "High", 100, "Project Lead", "Technical", "", "#367bf5", "First subtask"],
    ["Example Project", "T-102", "Approve plan", "T-100", "2026-09-11", "2026-09-18", "Not started", "Critical", 0, "Sponsor", "Finance, Legal", "T-101", "#f26b38", "Separate multiple dependencies or supporters with commas"],
  ]);
  const instructions = XLSX.utils.aoa_to_sheet([
    ["KarmCharge Project Management import guide"],
    ["1. Keep the Projects and Tasks sheet names unchanged."],
    ["2. Dates must use YYYY-MM-DD."],
    ["3. Status: Not started, In progress, Blocked, or Done."],
    ["4. Priority: Critical, High, Medium, or Low."],
    ["5. Every subtask uses its parent task ID in Parent Task ID."],
    ["6. Separate multiple Dependency IDs with commas."],
    ["7. Progress is a number from 0 to 100."],
    ["8. Add more than one project by repeating its name in the Tasks sheet."],
  ]);
  projects["!cols"] = [{ wch: 24 }, { wch: 48 }, { wch: 14 }];
  tasks["!cols"] = taskHeaders.map((header) => ({ wch: Math.max(14, header.length + 2) }));
  instructions["!cols"] = [{ wch: 88 }];
  XLSX.utils.book_append_sheet(workbook, projects, "Projects");
  XLSX.utils.book_append_sheet(workbook, tasks, "Tasks");
  XLSX.utils.book_append_sheet(workbook, instructions, "Instructions");
  XLSX.writeFile(workbook, "KarmCharge-Project-Management-Import-Template.xlsx");
}

export async function exportProjectExcel(project: Project) {
  const XLSX = await import("xlsx");
  const workbook = XLSX.utils.book_new();
  const overview = XLSX.utils.aoa_to_sheet([
    ["Project", project.name],
    ["Description", project.description],
    ["Tasks", project.tasks.length],
    ["Overall progress", `${Math.round(project.tasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, project.tasks.length))}%`],
    ["Exported", new Date().toISOString()],
  ]);
  const customHeaders = (project.customColumns ?? []).map((column) => column.name);
  const tasks = XLSX.utils.aoa_to_sheet([
    [...taskHeaders, ...customHeaders],
    ...project.tasks.map((task) => [
      project.name,
      task.id,
      task.name,
      task.parentId ?? "",
      task.start,
      task.end,
      task.status,
      task.priority,
      task.progress,
      task.owner,
      (task.supportedBy ?? []).join(", "),
      task.dependencies.join(", "),
      task.color,
      task.notes,
      ...(project.customColumns ?? []).map((column) => task.customFields?.[column.id] ?? ""),
    ]),
  ]);
  overview["!cols"] = [{ wch: 22 }, { wch: 58 }];
  tasks["!cols"] = [...taskHeaders, ...customHeaders].map((header) => ({ wch: Math.max(14, header.length + 2) }));
  XLSX.utils.book_append_sheet(workbook, overview, "Overview");
  XLSX.utils.book_append_sheet(workbook, tasks, "Tasks");
  XLSX.writeFile(workbook, `${safeFileName(project.name)}-Plan.xlsx`);
}

export async function importProjectsFromExcel(file: File): Promise<Project[]> {
  const XLSX = await import("xlsx");
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: "array", cellDates: false });
  const taskSheet = workbook.Sheets.Tasks ?? workbook.Sheets[workbook.SheetNames[0]];
  if (!taskSheet) throw new Error("The workbook does not contain a Tasks sheet.");
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(taskSheet, { defval: "" });
  if (!rows.length) throw new Error("The Tasks sheet is empty.");
  const projectSheet = workbook.Sheets.Projects;
  const projectRows = projectSheet ? XLSX.utils.sheet_to_json<Record<string, unknown>>(projectSheet, { defval: "" }) : [];
  const meta = new Map(projectRows.map((row) => [String(row.Project).trim(), row]));
  const grouped = new Map<string, Record<string, unknown>[]>();
  for (const row of rows) {
    const projectName = String(row.Project || "Imported Project").trim();
    grouped.set(projectName, [...(grouped.get(projectName) ?? []), row]);
  }
  return Array.from(grouped.entries()).map(([name, projectRowsForName], index) => {
    const info = meta.get(name);
    const color = String(info?.Color || "#0073ea");
    const normalizeDate = (value: unknown) => {
      if (typeof value === "number") {
        const parsed = XLSX.SSF.parse_date_code(value);
        if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
      }
      const text = String(value).trim();
      const match = text.match(/^\d{4}-\d{2}-\d{2}/);
      if (match) return match[0];
      const date = new Date(text);
      return Number.isNaN(date.getTime()) ? new Date().toISOString().slice(0, 10) : date.toISOString().slice(0, 10);
    };
    return {
      id: `imported-${Date.now()}-${index}`,
      name,
      description: String(info?.Description || "Imported from Excel"),
      color,
      createdAt: new Date().toISOString(),
      tasks: projectRowsForName.map((row, taskIndex) => ({
        id: String(row["Task ID"] || `T-${taskIndex + 1}`).trim(),
        name: String(row.Task || `Task ${taskIndex + 1}`).trim(),
        parentId: String(row["Parent Task ID"] || "").trim() || null,
        start: normalizeDate(row["Start Date"]),
        end: normalizeDate(row["End Date"]),
        status: (["Not started", "In progress", "Blocked", "Done"].includes(String(row.Status)) ? String(row.Status) : "Not started") as Project["tasks"][number]["status"],
        priority: (["Critical", "High", "Medium", "Low"].includes(String(row.Priority)) ? String(row.Priority) : "Medium") as Project["tasks"][number]["priority"],
        progress: Math.max(0, Math.min(100, Number(row["Progress %"]) || 0)),
        owner: String(row.Owner || "Unassigned"),
        supportedBy: String(row["Supported by"] || "").split(",").map((item) => item.trim()).filter(Boolean),
        dependencies: String(row["Dependency IDs"] || "").split(",").map((item) => item.trim()).filter(Boolean),
        color: String(row.Color || color),
        notes: String(row.Notes || ""),
      })),
    };
  });
}

export async function exportProjectPowerPoint(project: Project) {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = "KarmCharge Project Management";
  pptx.subject = `${project.name} Gantt plan`;
  pptx.title = project.name;
  pptx.company = "KarmCharge";
  pptx.theme = {
    headFontFace: "Aptos Display",
    bodyFontFace: "Aptos",
  };

  const overview = pptx.addSlide();
  overview.background = { color: "F6F7FB" };
  overview.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 3.4, h: 7.5, fill: { color: "111827" }, line: { color: "111827" } });
  overview.addText("KARMCHARGE PM", { x: 0.6, y: 0.55, w: 2.2, h: 0.35, fontFace: "Aptos", fontSize: 11, bold: true, color: "A7B0C3", charSpacing: 1.6, margin: 0 });
  overview.addText(project.name, { x: 0.6, y: 1.42, w: 2.25, h: 1.7, fontFace: "Aptos Display", fontSize: 26, bold: true, color: "FFFFFF", breakLine: false, valign: "middle", margin: 0 });
  overview.addText(project.description || "Project plan", { x: 0.6, y: 3.35, w: 2.2, h: 1.0, fontSize: 12, color: "C9D0DE", breakLine: false, margin: 0, valign: "top" });
  overview.addShape(pptx.ShapeType.rect, { x: 0.6, y: 6.4, w: 0.55, h: 0.1, fill: { color: project.color.replace("#", "") }, line: { color: project.color.replace("#", "") } });

  const progress = Math.round(project.tasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, project.tasks.length));
  const done = project.tasks.filter((task) => task.status === "Done").length;
  const blocked = project.tasks.filter((task) => task.status === "Blocked").length;
  overview.addText("Project snapshot", { x: 4.1, y: 0.9, w: 4.4, h: 0.55, fontSize: 24, bold: true, color: "111827", margin: 0 });
  [
    ["Overall progress", `${progress}%`],
    ["Tasks", String(project.tasks.length)],
    ["Completed", String(done)],
    ["Blocked", String(blocked)],
  ].forEach(([label, value], index) => {
    const x = 4.1 + (index % 2) * 3.75;
    const y = 1.8 + Math.floor(index / 2) * 1.6;
    overview.addShape(pptx.ShapeType.roundRect, { x, y, w: 3.25, h: 1.22, rectRadius: 0.08, fill: { color: "FFFFFF" }, line: { color: "E3E6EE", width: 1 } });
    overview.addText(value, { x: x + 0.28, y: y + 0.18, w: 1.4, h: 0.45, fontSize: 23, bold: true, color: "111827", margin: 0 });
    overview.addText(label, { x: x + 0.28, y: y + 0.72, w: 2.5, h: 0.25, fontSize: 10, color: "677085", margin: 0 });
  });
  overview.addText(`Exported ${new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}`, { x: 4.1, y: 6.55, w: 4.5, h: 0.25, fontSize: 9, color: "8A93A6", margin: 0 });

  const topLevelIds = new Set(project.tasks.filter((task) => !task.parentId).map((task) => task.id));
  const ordered = [...project.tasks].sort((a, b) => {
    const aParent = a.parentId ?? a.id;
    const bParent = b.parentId ?? b.id;
    if (aParent === bParent) return a.parentId ? 1 : -1;
    return project.tasks.findIndex((task) => task.id === aParent) - project.tasks.findIndex((task) => task.id === bParent);
  });
  const chunkSize = 12;
  for (let page = 0; page < Math.ceil(ordered.length / chunkSize); page += 1) {
    const tasks = ordered.slice(page * chunkSize, (page + 1) * chunkSize);
    const allStart = new Date(`${project.tasks.reduce((min, task) => task.start < min ? task.start : min, project.tasks[0]?.start ?? new Date().toISOString().slice(0, 10))}T00:00:00Z`);
    const allEnd = new Date(`${project.tasks.reduce((max, task) => task.end > max ? task.end : max, project.tasks[0]?.end ?? new Date().toISOString().slice(0, 10))}T00:00:00Z`);
    const totalDays = Math.max(1, daysBetween(allStart.toISOString().slice(0, 10), allEnd.toISOString().slice(0, 10)));
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" };
    slide.addText(project.name, { x: 0.55, y: 0.35, w: 5.5, h: 0.45, fontSize: 20, bold: true, color: "111827", margin: 0 });
    slide.addText(`Timeline · ${page + 1} / ${Math.ceil(ordered.length / chunkSize)}`, { x: 9.8, y: 0.43, w: 2.9, h: 0.3, fontSize: 10, color: "677085", align: "right", margin: 0 });
    const labelX = 0.55;
    const labelW = 3.25;
    const chartX = 4.0;
    const chartW = 8.7;
    const chartY = 1.25;
    const rowH = 0.44;
    slide.addShape(pptx.ShapeType.line, { x: chartX, y: 1.08, w: chartW, h: 0, line: { color: "D9DEE8", width: 1 } });
    slide.addText(allStart.toLocaleDateString("en-GB", { day: "numeric", month: "short" }), { x: chartX, y: 0.86, w: 1.2, h: 0.2, fontSize: 8, color: "7B8496", margin: 0 });
    slide.addText(allEnd.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }), { x: chartX + chartW - 1.2, y: 0.86, w: 1.2, h: 0.2, fontSize: 8, color: "7B8496", align: "right", margin: 0 });
    tasks.forEach((task, index) => {
      const y = chartY + index * rowH;
      const isParent = topLevelIds.has(task.id);
      if (index % 2 === 0) slide.addShape(pptx.ShapeType.rect, { x: 0.45, y: y - 0.04, w: 12.35, h: rowH, fill: { color: "F8F9FC", transparency: 0 }, line: { color: "F8F9FC", transparency: 100 } });
      slide.addText(task.name, { x: labelX + (task.parentId ? 0.22 : 0), y: y + 0.055, w: labelW - (task.parentId ? 0.22 : 0), h: 0.22, fontSize: isParent ? 9.5 : 8.5, bold: isParent, color: "252B37", margin: 0, breakLine: false, valign: "middle" });
      const offset = Math.max(0, daysBetween(allStart.toISOString().slice(0, 10), task.start) - 1);
      const duration = daysBetween(task.start, task.end);
      const x = chartX + (offset / totalDays) * chartW;
      const w = Math.max(0.13, (duration / totalDays) * chartW);
      const barColor = task.color.replace("#", "");
      slide.addShape(pptx.ShapeType.roundRect, { x, y: y + 0.04, w, h: 0.27, rectRadius: 0.04, fill: { color: barColor }, line: { color: barColor } });
      if (w > 1.1) slide.addText(task.name, { x: x + 0.08, y: y + 0.09, w: w - 0.16, h: 0.14, fontSize: 6.5, bold: true, color: "FFFFFF", margin: 0, breakLine: false, valign: "middle" });
    });
    slide.addText("KarmCharge Project Management", { x: 10.0, y: 7.05, w: 2.7, h: 0.2, fontSize: 8, color: "A0A8B8", align: "right", margin: 0 });
  }
  await pptx.writeFile({ fileName: `${safeFileName(project.name)}-Gantt.pptx` });
}
