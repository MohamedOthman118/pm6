"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowDown,
  ArrowDownToLine,
  ArrowUp,
  BarChart3,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Columns3,
  Clock3,
  Copy,
  Download,
  ExternalLink,
  FileDown,
  FileSpreadsheet,
  Filter,
  FolderKanban,
  Gauge,
  ImagePlus,
  Link2,
  LayoutGrid,
  ListTree,
  Menu,
  MonitorPlay,
  MoreHorizontal,
  Plus,
  Search,
  Share2,
  Settings2,
  Trash2,
  Upload,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";

import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from "recharts";

import { downloadExcelTemplate, exportProjectExcel, exportProjectPowerPoint, importProjectsFromExcel } from "./exporters";
import ManagerView from "./manager-view";
import { defaultDashboardWidgets, emptyProject, palette, priorityOrder, starterProjects, statusOrder, type CustomColumn, type CustomColumnType, type DashboardWidgetId, type Priority, type Project, type Task, type TaskStatus, type TeamMember, uid } from "./model";

const STORAGE_KEY = "planforge.workspace.v1";
const DAY = 86400000;

const priorityStyles: Record<Priority, string> = {
  Critical: "bg-red-50 text-red-700 ring-red-600/15",
  High: "bg-orange-50 text-orange-700 ring-orange-600/15",
  Medium: "bg-blue-50 text-blue-700 ring-blue-600/15",
  Low: "bg-slate-100 text-slate-600 ring-slate-500/15",
};

const statusStyles: Record<TaskStatus, string> = {
  "Not started": "bg-slate-100 text-slate-700",
  "In progress": "bg-blue-100 text-blue-700",
  Blocked: "bg-red-100 text-red-700",
  Done: "bg-emerald-100 text-emerald-700",
};

function cloneStarterProjects() {
  return JSON.parse(JSON.stringify(starterProjects)) as Project[];
}

function dateMs(value: string) {
  return new Date(`${value}T00:00:00Z`).getTime();
}

function addDays(value: string, days: number) {
  return new Date(dateMs(value) + days * DAY).toISOString().slice(0, 10);
}

function formatDate(value: string, options?: Intl.DateTimeFormatOptions) {
  return new Date(`${value}T00:00:00Z`).toLocaleDateString("en-GB", options ?? { day: "numeric", month: "short" });
}

function taskDuration(task: Task) {
  return Math.max(1, Math.round((dateMs(task.end) - dateMs(task.start)) / DAY) + 1);
}

function childrenOf(tasks: Task[], parentId: string) {
  return tasks.filter((task) => task.parentId === parentId);
}

function orderedTasks(tasks: Task[]) {
  const result: Task[] = [];
  const visited = new Set<string>();
  const walk = (task: Task) => {
    if (visited.has(task.id)) return;
    visited.add(task.id);
    result.push(task);
    tasks.filter((child) => child.parentId === task.id).forEach(walk);
  };
  tasks.filter((task) => !task.parentId || !tasks.some((candidate) => candidate.id === task.parentId)).forEach(walk);
  tasks.filter((task) => !visited.has(task.id)).forEach(walk);
  return result;
}

function getTaskDepth(task: Task, tasks: Task[]) {
  let depth = 0;
  let parentId = task.parentId;
  const seen = new Set<string>();
  while (parentId && !seen.has(parentId) && depth < 3) {
    seen.add(parentId);
    depth += 1;
    parentId = tasks.find((candidate) => candidate.id === parentId)?.parentId ?? null;
  }
  return depth;
}

function timelineBounds(tasks: Task[]) {
  const fallback = new Date().toISOString().slice(0, 10);
  const earliest = tasks.reduce((min, task) => task.start < min ? task.start : min, tasks[0]?.start ?? fallback);
  const latest = tasks.reduce((max, task) => task.end > max ? task.end : max, tasks[0]?.end ?? addDays(fallback, 28));
  const first = new Date(`${earliest}T00:00:00Z`);
  const day = (first.getUTCDay() + 6) % 7;
  const start = new Date(first.getTime() - (day + 7) * DAY).toISOString().slice(0, 10);
  const end = addDays(latest, 14);
  const count = Math.max(6, Math.ceil((dateMs(end) - dateMs(start)) / (7 * DAY)));
  return { start, count };
}

function taskHasUnfinishedDependency(task: Task, tasks: Task[]) {
  return task.dependencies.some((id) => {
    const dependency = tasks.find((candidate) => candidate.id === id);
    return dependency ? dependency.status !== "Done" : false;
  });
}

function compactId(id: string) {
  return id.length > 12 ? `${id.slice(0, 9)}…` : id;
}

type TaskDraft = Task;
type WorkspaceView = "table" | "board" | "gantt" | "calendar" | "dashboard";
type TaskFocus = "all" | "open" | "due-soon" | "overdue" | "blocked" | "done";

function teamMembersForProject(project: Project) {
  const saved = project.team ?? [];
  const savedNames = new Set(saved.map((member) => member.name));
  const inferred = Array.from(new Set(project.tasks.flatMap((task) => [task.owner, ...(task.supportedBy ?? [])]).filter((name) => name && name !== "Unassigned")))
    .filter((name) => !savedNames.has(name))
    .map((name, index): TeamMember => ({ id: `inferred-${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`, name, role: "Project contributor", color: palette[index % palette.length] }));
  return [...saved, ...inferred];
}

function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "?";
}

const newTaskDraft = (project: Project, parentId: string | null): TaskDraft => {
  const parent = parentId ? project.tasks.find((task) => task.id === parentId) : null;
  const today = new Date().toISOString().slice(0, 10);
  return {
    id: uid(parent ? "S" : "T"),
    name: parent ? "New subtask" : "New workstream",
    parentId,
    start: parent?.start ?? today,
    end: parent?.end ?? addDays(today, 7),
    status: "Not started",
    priority: parent?.priority ?? "Medium",
    progress: 0,
    owner: parent?.owner ?? "Unassigned",
    supportedBy: parent?.supportedBy ?? [],
    dependencies: parent ? [] : project.tasks.length ? [project.tasks[project.tasks.length - 1].id] : [],
    color: parent?.color ?? project.color,
    notes: "",
    customFields: {},
  };
};

export default function Planner() {
  const [projects, setProjects] = useState<Project[]>(cloneStarterProjects);
  const [activeProjectId, setActiveProjectId] = useState(starterProjects[0].id);
  const [hydrated, setHydrated] = useState(false);
  const [view, setView] = useState<WorkspaceView>("table");
  const [search, setSearch] = useState("");
  const [priorityFilter, setPriorityFilter] = useState<Priority | "All">("All");
  const [taskFocus, setTaskFocus] = useState<TaskFocus>("all");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [weekWidth, setWeekWidth] = useState(72);
  const [taskDraft, setTaskDraft] = useState<TaskDraft | null>(null);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);
  const [projectDeleteOpen, setProjectDeleteOpen] = useState(false);
  const [presentationOpen, setPresentationOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [shareLoading, setShareLoading] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [shareError, setShareError] = useState("");
  const [shareSyncStatus, setShareSyncStatus] = useState<"idle" | "syncing" | "synced" | "error">("idle");
  const [teamDialogOpen, setTeamDialogOpen] = useState(false);
  const [memberDraft, setMemberDraft] = useState({ name: "", role: "" });
  const [memberPhoto, setMemberPhoto] = useState<File | null>(null);
  const [memberUploading, setMemberUploading] = useState(false);
  const [columnDialogOpen, setColumnDialogOpen] = useState(false);
  const [columnDraft, setColumnDraft] = useState<{ name: string; type: CustomColumnType; options: string }>({ name: "", type: "text", options: "" });
  const [projectDialogMode, setProjectDialogMode] = useState<"new" | "edit">("new");
  const [projectDraft, setProjectDraft] = useState({ name: "", description: "", color: palette[0] });
  const [mobileProjectsOpen, setMobileProjectsOpen] = useState(false);
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState<"excel" | "powerpoint" | "pdf" | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const saved = JSON.parse(raw) as { projects?: Project[]; activeProjectId?: string };
          if (saved.projects?.length) {
            setProjects(saved.projects);
            setActiveProjectId(saved.projects.some((project) => project.id === saved.activeProjectId) ? saved.activeProjectId! : saved.projects[0].id);
          }
        }
      } catch {
        toast.error("Saved browser data could not be opened. The example workspace was loaded instead.");
      } finally {
        setHydrated(true);
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ projects, activeProjectId }));
  }, [projects, activeProjectId, hydrated]);

  const activeProject = projects.find((project) => project.id === activeProjectId) ?? projects[0];

  const updateActiveProject = (updater: (project: Project) => Project) => {
    setProjects((current) => current.map((project) => project.id === activeProject.id ? updater(project) : project));
  };

  const visibleTasks = useMemo(() => {
    if (!activeProject) return [];
    const matches = new Set<string>();
    const query = search.trim().toLowerCase();
    const today = new Date().toISOString().slice(0, 10);
    const soon = addDays(today, 14);
    const includeAncestors = (task: Task) => {
      let parentId = task.parentId;
      const seen = new Set<string>();
      while (parentId && !seen.has(parentId)) {
        seen.add(parentId);
        matches.add(parentId);
        parentId = activeProject.tasks.find((candidate) => candidate.id === parentId)?.parentId ?? null;
      }
    };
    for (const task of activeProject.tasks) {
      const textMatch = !query || `${task.name} ${task.owner} ${task.id} ${task.notes}`.toLowerCase().includes(query);
      const priorityMatch = priorityFilter === "All" || task.priority === priorityFilter;
      const focusMatch = taskFocus === "all"
        || (taskFocus === "open" && task.status !== "Done")
        || (taskFocus === "due-soon" && task.status !== "Done" && task.end >= today && task.end <= soon)
        || (taskFocus === "overdue" && task.status !== "Done" && task.end < today)
        || (taskFocus === "blocked" && (task.status === "Blocked" || taskHasUnfinishedDependency(task, activeProject.tasks)))
        || (taskFocus === "done" && task.status === "Done");
      if (textMatch && priorityMatch && focusMatch) {
        matches.add(task.id);
        includeAncestors(task);
      }
    }
    return orderedTasks(activeProject.tasks).filter((task) => {
      if (!matches.has(task.id)) return false;
      let parentId = task.parentId;
      const seen = new Set<string>();
      while (parentId && !seen.has(parentId)) {
        seen.add(parentId);
        if (collapsed.has(parentId)) return false;
        parentId = activeProject.tasks.find((candidate) => candidate.id === parentId)?.parentId ?? null;
      }
      return true;
    });
  }, [activeProject, search, priorityFilter, taskFocus, collapsed]);

  const stats = useMemo(() => {
    const tasks = activeProject?.tasks ?? [];
    const leafTasks = tasks.filter((task) => !tasks.some((candidate) => candidate.parentId === task.id));
    const progress = Math.round(leafTasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, leafTasks.length));
    const done = leafTasks.filter((task) => task.status === "Done").length;
    const blocked = leafTasks.filter((task) => task.status === "Blocked" || taskHasUnfinishedDependency(task, tasks)).length;
    const owners = new Set(leafTasks.map((task) => task.owner).filter((owner) => owner && owner !== "Unassigned")).size;
    const today = new Date().toISOString().slice(0, 10);
    const soon = addDays(today, 14);
    const overdue = leafTasks.filter((task) => task.status !== "Done" && task.end < today).length;
    const dueSoon = leafTasks.filter((task) => task.status !== "Done" && task.end >= today && task.end <= soon).length;
    return { progress, done, blocked, owners, overdue, dueSoon, total: leafTasks.length };
  }, [activeProject]);

  useEffect(() => {
    if (!hydrated || !activeProject?.shareId || !activeProject?.shareToken) return;
    const timer = window.setTimeout(async () => {
      setShareSyncStatus("syncing");
      try {
        const response = await fetch(`/api/shares/${activeProject.shareId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json", "x-share-edit-token": activeProject.shareToken },
          body: JSON.stringify({ project: activeProject }),
        });
        setShareSyncStatus(response.ok ? "synced" : "error");
      } catch {
        setShareSyncStatus("error");
      }
    }, 1200);
    return () => window.clearTimeout(timer);
  }, [activeProject, hydrated]);

  if (!activeProject) return null;

  const openNewProject = () => {
    setProjectDialogMode("new");
    setProjectDraft({ name: "Untitled project", description: "", color: palette[projects.length % palette.length] });
    setProjectDialogOpen(true);
  };

  const openProjectSettings = () => {
    setProjectDialogMode("edit");
    setProjectDraft({ name: activeProject.name, description: activeProject.description, color: activeProject.color });
    setProjectDialogOpen(true);
  };

  const saveProject = () => {
    if (!projectDraft.name.trim()) {
      toast.error("Add a project name first.");
      return;
    }
    if (projectDialogMode === "new") {
      const project = emptyProject(projectDraft.name.trim(), projectDraft.color);
      project.description = projectDraft.description.trim() || "New project workspace";
      setProjects((current) => [...current, project]);
      setActiveProjectId(project.id);
      toast.success("Project created with a starter workstream and subtask.");
    } else {
      updateActiveProject((project) => ({ ...project, ...projectDraft, name: projectDraft.name.trim() }));
      toast.success("Project settings updated.");
    }
    setProjectDialogOpen(false);
  };

  const duplicateProject = () => {
    const suffix = Date.now().toString(36);
    const idMap = new Map(activeProject.tasks.map((task) => [task.id, `${task.id}-${suffix}`]));
    const duplicate: Project = {
      ...activeProject,
      id: `project-${suffix}`,
      name: `${activeProject.name} copy`,
      createdAt: new Date().toISOString(),
      shareId: undefined,
      shareToken: undefined,
      tasks: activeProject.tasks.map((task) => ({
        ...task,
        id: idMap.get(task.id)!,
        parentId: task.parentId ? idMap.get(task.parentId) ?? null : null,
        dependencies: task.dependencies.map((id) => idMap.get(id)).filter(Boolean) as string[],
      })),
    };
    setProjects((current) => [...current, duplicate]);
    setActiveProjectId(duplicate.id);
    toast.success("Project duplicated.");
  };

  const deleteActiveProject = () => {
    if (projects.length === 1) {
      toast.error("Keep at least one project in the workspace.");
      setProjectDeleteOpen(false);
      return;
    }
    const next = projects.filter((project) => project.id !== activeProject.id);
    setProjects(next);
    setActiveProjectId(next[0].id);
    setProjectDeleteOpen(false);
    toast.success("Project deleted.");
  };

  const openTask = (task: Task) => {
    setEditingTaskId(task.id);
    setTaskDraft({ ...task, dependencies: [...task.dependencies] });
  };

  const addTask = (parentId: string | null = null, initial: Partial<Task> = {}) => {
    setEditingTaskId(null);
    setTaskDraft({ ...newTaskDraft(activeProject, parentId), ...initial });
  };

  const saveTask = () => {
    if (!taskDraft?.name.trim()) {
      toast.error("Add a task name first.");
      return;
    }
    if (taskDraft.end < taskDraft.start) {
      toast.error("The end date must be on or after the start date.");
      return;
    }
    updateActiveProject((project) => {
      if (editingTaskId) {
        return { ...project, tasks: project.tasks.map((task) => task.id === editingTaskId ? taskDraft : task) };
      }
      return { ...project, tasks: [...project.tasks, taskDraft] };
    });
    toast.success(editingTaskId ? "Task updated." : taskDraft.parentId ? "Subtask added." : "Task added.");
    setTaskDraft(null);
    setEditingTaskId(null);
  };

  const confirmDeleteTask = () => {
    if (!taskToDelete) return;
    const removedIds = new Set<string>();
    const collect = (id: string) => {
      if (removedIds.has(id)) return;
      removedIds.add(id);
      activeProject.tasks.filter((task) => task.parentId === id).forEach((child) => collect(child.id));
    };
    collect(taskToDelete.id);
    updateActiveProject((project) => ({
      ...project,
      tasks: project.tasks
        .filter((task) => !removedIds.has(task.id))
        .map((task) => ({ ...task, dependencies: task.dependencies.filter((id) => !removedIds.has(id)) })),
    }));
    setTaskToDelete(null);
    setTaskDraft(null);
    setEditingTaskId(null);
    toast.success(removedIds.size > 1 ? "Task and all nested subtasks deleted." : "Task deleted.");
  };

  const changeTaskStatus = (taskId: string, status: TaskStatus) => {
    updateActiveProject((project) => ({
      ...project,
      tasks: project.tasks.map((task) => {
        if (task.id !== taskId) return task;
        const progress = status === "Done" ? 100 : task.status === "Done" && task.progress === 100 ? (status === "Not started" ? 0 : 50) : task.progress;
        return { ...task, status, progress };
      }),
    }));
  };

  const moveTask = (taskId: string, direction: -1 | 1) => {
    updateActiveProject((project) => {
      const task = project.tasks.find((candidate) => candidate.id === taskId);
      if (!task) return project;
      const siblings = project.tasks.filter((candidate) => candidate.parentId === task.parentId);
      const siblingIndex = siblings.findIndex((candidate) => candidate.id === taskId);
      const target = siblings[siblingIndex + direction];
      if (!target) return project;
      const tasks = [...project.tasks];
      const sourceIndex = tasks.findIndex((candidate) => candidate.id === taskId);
      const targetIndex = tasks.findIndex((candidate) => candidate.id === target.id);
      [tasks[sourceIndex], tasks[targetIndex]] = [tasks[targetIndex], tasks[sourceIndex]];
      return { ...project, tasks };
    });
  };

  const extendTask = (taskId: string, days: number) => {
    updateActiveProject((project) => ({ ...project, tasks: project.tasks.map((task) => task.id === taskId ? { ...task, end: addDays(task.end, days) } : task) }));
    toast.success(`${days} day${days === 1 ? "" : "s"} added to the task.`);
  };

  const duplicateTask = (taskId: string) => {
    updateActiveProject((project) => {
      const source = project.tasks.find((task) => task.id === taskId);
      if (!source) return project;
      const descendants: Task[] = [];
      const collect = (id: string) => project.tasks.filter((task) => task.parentId === id).forEach((child) => { descendants.push(child); collect(child.id); });
      collect(taskId);
      const originals = [source, ...descendants];
      const idMap = new Map(originals.map((task) => [task.id, uid(task.parentId ? "S" : "T")]));
      const copies = originals.map((task, index) => ({
        ...task,
        id: idMap.get(task.id)!,
        name: index === 0 ? `${task.name} copy` : task.name,
        parentId: task.id === source.id ? source.parentId : task.parentId ? idMap.get(task.parentId) ?? task.parentId : null,
        dependencies: task.dependencies.map((dependency) => idMap.get(dependency) ?? dependency),
        supportedBy: [...(task.supportedBy ?? [])],
        customFields: { ...(task.customFields ?? {}) },
      }));
      const lastIndex = Math.max(...originals.map((task) => project.tasks.findIndex((candidate) => candidate.id === task.id)));
      const tasks = [...project.tasks];
      tasks.splice(lastIndex + 1, 0, ...copies);
      return { ...project, tasks };
    });
    toast.success("Task duplicated.");
  };

  const updateTask = (taskId: string, patch: Partial<Task>) => {
    updateActiveProject((project) => ({
      ...project,
      tasks: project.tasks.map((task) => {
        if (task.id !== taskId) return task;
        const next = { ...task, ...patch };
        if (patch.status === "Done" && patch.progress === undefined) next.progress = 100;
        if (patch.status && patch.status !== "Done" && task.status === "Done" && task.progress === 100 && patch.progress === undefined) next.progress = patch.status === "Not started" ? 0 : 50;
        if (patch.progress === 100 && patch.status === undefined) next.status = "Done";
        if (patch.progress !== undefined && patch.progress < 100 && task.status === "Done" && patch.status === undefined) next.status = patch.progress > 0 ? "In progress" : "Not started";
        if (patch.start && patch.start > next.end) next.end = patch.start;
        if (patch.end && patch.end < next.start) next.start = patch.end;
        return next;
      }),
    }));
  };

  const shiftTaskToDate = (taskId: string, start: string) => {
    const task = activeProject.tasks.find((candidate) => candidate.id === taskId);
    if (!task) return;
    updateTask(taskId, { start, end: addDays(start, taskDuration(task) - 1) });
  };

  const addTeamMember = async () => {
    if (!memberDraft.name.trim()) {
      toast.error("Add the team member’s name first.");
      return;
    }
    setMemberUploading(true);
    try {
      let avatarUrl: string | undefined;
      if (memberPhoto) {
        const form = new FormData();
        form.append("file", memberPhoto);
        const response = await fetch("/api/team-images", { method: "POST", body: form });
        const data = await response.json() as { url?: string; error?: string };
        if (!response.ok || !data.url) throw new Error(data.error || "The team photo could not be uploaded.");
        avatarUrl = data.url;
      }
      const member: TeamMember = {
        id: uid("M"),
        name: memberDraft.name.trim(),
        role: memberDraft.role.trim() || "Project contributor",
        avatarUrl,
        color: palette[(activeProject.team?.length ?? 0) % palette.length],
      };
      updateActiveProject((project) => ({ ...project, team: [...(project.team ?? []), member] }));
      setMemberDraft({ name: "", role: "" });
      setMemberPhoto(null);
      toast.success("Team member added and ready for assignment.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The team member could not be added.");
    } finally {
      setMemberUploading(false);
    }
  };

  const addCustomColumn = () => {
    if (!columnDraft.name.trim()) {
      toast.error("Add a column name first.");
      return;
    }
    const options = columnDraft.options.split(",").map((option) => option.trim()).filter(Boolean);
    if (columnDraft.type === "select" && !options.length) {
      toast.error("Add at least one dropdown option.");
      return;
    }
    const column: CustomColumn = { id: uid("C"), name: columnDraft.name.trim(), type: columnDraft.type, options: columnDraft.type === "select" ? options : undefined };
    updateActiveProject((project) => ({ ...project, customColumns: [...(project.customColumns ?? []), column] }));
    setColumnDraft({ name: "", type: "text", options: "" });
    setColumnDialogOpen(false);
    toast.success("Custom column added to the spreadsheet.");
  };

  const setDashboardWidgets = (widgets: DashboardWidgetId[]) => {
    updateActiveProject((project) => ({ ...project, dashboardWidgets: widgets }));
  };

  const shareToManager = async () => {
    setShareDialogOpen(true);
    setShareLoading(true);
    setShareError("");
    setShareUrl("");
    try {
      const existingId = activeProject.shareId;
      const existingToken = activeProject.shareToken;
      const canUpdateExisting = Boolean(existingId && existingToken);
      const response = await fetch(canUpdateExisting ? `/api/shares/${existingId}` : "/api/shares", {
        method: canUpdateExisting ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          ...(canUpdateExisting ? { "x-share-edit-token": existingToken! } : {}),
        },
        body: JSON.stringify({ project: activeProject }),
      });
      const data = await response.json() as { shareId?: string; editToken?: string; error?: string };
      if (!response.ok) throw new Error(data.error || "The manager link could not be created.");
      const shareId = canUpdateExisting ? existingId! : data.shareId;
      const shareToken = canUpdateExisting ? existingToken! : data.editToken;
      if (!shareId || !shareToken) throw new Error("The manager link could not be created.");
      if (!canUpdateExisting) updateActiveProject((project) => ({ ...project, shareId, shareToken }));
      const url = `${window.location.origin}/share/${shareId}`;
      setShareUrl(url);
      setShareSyncStatus("synced");
    } catch (error) {
      setShareError(error instanceof Error ? error.message : "The manager link could not be created.");
    } finally {
      setShareLoading(false);
    }
  };

  const copyShareLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
    } catch {
      const input = document.createElement("textarea");
      input.value = shareUrl;
      input.style.position = "fixed";
      input.style.opacity = "0";
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    toast.success("Manager link copied.");
  };

  const handleImport = async (file?: File) => {
    if (!file) return;
    setImporting(true);
    try {
      const imported = await importProjectsFromExcel(file);
      if (!imported.length) throw new Error("No projects were found.");
      setProjects((current) => [...current, ...imported]);
      setActiveProjectId(imported[0].id);
      toast.success(`${imported.length} project${imported.length === 1 ? "" : "s"} imported.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The spreadsheet could not be imported.");
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleExport = async (type: "excel" | "powerpoint" | "pdf") => {
    setExporting(type);
    try {
      if (type === "excel") await exportProjectExcel(activeProject);
      else if (type === "powerpoint") await exportProjectPowerPoint(activeProject);
      else {
        const target = workspaceRef.current;
        if (!target) throw new Error("The selected view is not ready.");
        const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
        const captureScale = Math.max(0.65, Math.min(1.5, 12000 / Math.max(target.scrollWidth, target.scrollHeight)));
        const canvas = await html2canvas(target, { backgroundColor: "#ffffff", scale: captureScale, useCORS: true, logging: false, width: target.scrollWidth, height: target.scrollHeight, windowWidth: target.scrollWidth, windowHeight: target.scrollHeight });
        const orientation = canvas.width > canvas.height ? "landscape" : "portrait";
        const pdf = new jsPDF({ orientation, unit: "px", format: "a4", hotfixes: ["px_scaling"] });
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();
        const imageHeight = canvas.height * (pageWidth / canvas.width);
        const image = canvas.toDataURL("image/png");
        let y = 0;
        pdf.addImage(image, "PNG", 0, y, pageWidth, imageHeight, undefined, "FAST");
        while (imageHeight + y > pageHeight) {
          y -= pageHeight;
          pdf.addPage();
          pdf.addImage(image, "PNG", 0, y, pageWidth, imageHeight, undefined, "FAST");
        }
        pdf.save(`${activeProject.name.replace(/[^a-z0-9]+/gi, "-")}-${view}.pdf`);
      }
      toast.success(`${type === "excel" ? "Excel workbook" : type === "powerpoint" ? "PowerPoint deck" : `${view} view PDF`} downloaded.`);
    } catch {
      toast.error(`The ${type} export could not be created.`);
    } finally {
      setExporting(null);
    }
  };

  const parentTaskIds = activeProject.tasks.filter((task) => childrenOf(activeProject.tasks, task.id).length).map((task) => task.id);
  const allTasksCollapsed = parentTaskIds.length > 0 && parentTaskIds.every((id) => collapsed.has(id));

  const projectRail = (
    <div className="flex h-full flex-col border-r border-slate-200/80 bg-[#f7f8fa] text-slate-900">
      <div className="flex h-16 items-center gap-3 px-4">
        <div className="grid size-9 place-items-center rounded-xl bg-[#0073ea] text-white shadow-sm">
          <BarChart3 className="size-5" />
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold tracking-tight">KarmCharge</div>
          <div className="text-xs text-slate-500">Work management</div>
        </div>
      </div>
      <div className="mx-3 border-t border-slate-200/80" />
      <div className="flex items-center justify-between px-4 pb-2 pt-5">
        <span className="text-[0.7rem] font-semibold uppercase tracking-[0.13em] text-slate-400">Projects</span>
        <Button onClick={openNewProject} size="icon" variant="ghost" className="size-8 rounded-lg text-slate-500 hover:bg-white hover:text-[#0073ea]" aria-label="Create project">
          <Plus className="size-4" />
        </Button>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto px-3" aria-label="Projects">
        {projects.map((project) => {
          const selected = project.id === activeProject.id;
          const actionable = project.tasks.filter((task) => !project.tasks.some((candidate) => candidate.parentId === task.id));
          const projectProgress = Math.round(actionable.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, actionable.length));
          return (
            <div key={project.id} className={`group flex items-start rounded-xl border transition ${selected ? "border-slate-200 bg-white shadow-sm" : "border-transparent hover:bg-white/80"}`}>
              <button type="button" onClick={() => { setActiveProjectId(project.id); setMobileProjectsOpen(false); }} className="min-w-0 flex-1 px-3 py-2.5 text-left">
                <span className="flex items-start gap-3">
                  <span className="mt-1.5 size-2.5 shrink-0 rounded-full" style={{ backgroundColor: project.color }} />
                  <span className="min-w-0 flex-1">
                    <span className={`block truncate text-sm ${selected ? "font-semibold text-slate-950" : "font-medium text-slate-700"}`}>{project.name}</span>
                    <span className="mt-0.5 block text-xs text-slate-400">{actionable.length} items · {projectProgress}%</span>
                  </span>
                </span>
              </button>
              <button type="button" onClick={() => { setActiveProjectId(project.id); setMobileProjectsOpen(false); setProjectDeleteOpen(true); }} className="mr-2 mt-2 rounded-md p-1.5 text-slate-300 opacity-0 transition hover:bg-red-50 hover:text-red-500 focus:opacity-100 group-hover:opacity-100" aria-label={`Delete ${project.name}`}><X className="size-3.5" /></button>
            </div>
          );
        })}
      </nav>
      <div className="m-3 rounded-xl border border-slate-200 bg-white p-3.5 shadow-sm">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700"><CircleDot className="size-3.5 text-emerald-500" /> {activeProject.shareId ? "Shared manager view" : "Saved locally"}</div>
        <p className="mt-1.5 text-xs leading-5 text-slate-400">{activeProject.shareId ? shareSyncStatus === "syncing" ? "Syncing latest changes…" : shareSyncStatus === "error" ? "Manager sync needs attention." : "Manager view sync is active." : "Changes save automatically on this device."}</p>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#f7f8fa] text-[#202124]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[240px] lg:block">{projectRail}</aside>
      <Sheet open={mobileProjectsOpen} onOpenChange={setMobileProjectsOpen}>
        <SheetContent side="left" className="w-[285px] border-0 p-0">
          <SheetHeader className="sr-only"><SheetTitle>Projects</SheetTitle><SheetDescription>Choose or create a project.</SheetDescription></SheetHeader>
          {projectRail}
        </SheetContent>
      </Sheet>

      <main className="min-w-0 flex-1 lg:ml-[240px]">
        <header className="sticky top-0 z-20 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
          <div className="flex min-h-16 items-center gap-3 px-4 sm:px-6 xl:px-8">
            <Button variant="ghost" size="icon" onClick={() => setMobileProjectsOpen(true)} className="lg:hidden" aria-label="Open project list"><Menu className="size-5" /></Button>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h1 className="truncate text-lg font-bold tracking-tight sm:text-xl">{activeProject.name}</h1>
                <button type="button" onClick={openProjectSettings} className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label="Project settings"><Settings2 className="size-4" /></button>
              </div>
              <p className="hidden truncate text-sm text-slate-500 sm:block">{activeProject.description}</p>
            </div>
            <input ref={fileInputRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(event) => handleImport(event.target.files?.[0])} />
            <Button variant="outline" onClick={() => setTeamDialogOpen(true)} className="hidden gap-2 lg:inline-flex"><Users className="size-4" /> Team</Button>
            <Button onClick={shareToManager} className="hidden gap-2 bg-[#0073ea] text-white hover:bg-[#0060b9] md:inline-flex"><Share2 className="size-4" /> Share</Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 bg-white" disabled={!!exporting}><Download className="size-4" /> <span className="hidden sm:inline">{exporting ? "Creating…" : "Export"}</span></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>Download current project</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleExport("excel")}><FileSpreadsheet className="size-4 text-emerald-600" /> Excel workbook</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport("powerpoint")}><FileDown className="size-4 text-orange-600" /> PowerPoint deck</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport("pdf")}><FileDown className="size-4 text-red-600" /> PDF · current {view} view</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="More project actions"><MoreHorizontal className="size-5" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuItem onClick={() => setPresentationOpen(true)}><MonitorPlay className="size-4" /> Presentation mode</DropdownMenuItem>
                <DropdownMenuItem onClick={() => fileInputRef.current?.click()} disabled={importing}><Upload className="size-4" /> {importing ? "Importing…" : "Import Excel"}</DropdownMenuItem>
                <DropdownMenuItem onClick={() => downloadExcelTemplate().catch(() => toast.error("The template could not be downloaded."))}><ArrowDownToLine className="size-4" /> Excel template</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={shareToManager} className="md:hidden"><Share2 className="size-4" /> Share with manager</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTeamDialogOpen(true)} className="lg:hidden"><Users className="size-4" /> Manage team</DropdownMenuItem>
                <DropdownMenuItem onClick={openProjectSettings}><Settings2 className="size-4" /> Project settings</DropdownMenuItem>
                <DropdownMenuItem onClick={duplicateProject}><Copy className="size-4" /> Duplicate project</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setProjectDeleteOpen(true)} className="text-red-600 focus:text-red-700"><Trash2 className="size-4" /> Delete project</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="px-4 py-4 sm:px-6 xl:px-8 xl:py-6">
          <section className="mb-4 grid grid-cols-2 gap-2 xl:grid-cols-4" aria-label="Project summary">
            <SummaryCard label="Overall progress" value={`${stats.progress}%`} detail={`${stats.done} of ${stats.total} tasks done`} icon={<BarChart3 className="size-4" />} accent={activeProject.color} progress={stats.progress} />
            <SummaryCard label="Blocked or waiting" value={String(stats.blocked)} detail={stats.blocked ? "Review dependencies" : "No dependency issues"} icon={<AlertTriangle className="size-4" />} accent="#f26b38" />
            <SummaryCard label="Due soon" value={String(stats.dueSoon)} detail="Next 14 days" icon={<Clock3 className="size-4" />} accent="#367bf5" />
            <SummaryCard label="Overdue" value={String(stats.overdue)} detail={stats.overdue ? "Needs attention" : "Nothing overdue"} icon={<AlertTriangle className="size-4" />} accent="#ef4444" />
          </section>

          <section className="overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-[0_1px_2px_rgba(15,23,42,.04)]">
            <div className="flex flex-col gap-3 border-b border-slate-200/80 px-3 py-3 xl:flex-row xl:items-center xl:justify-between">
              <div className="flex items-center gap-2 overflow-x-auto pb-1 xl:pb-0">
                <Tabs value={view} onValueChange={(value) => setView(value as typeof view)}>
                  <TabsList className="h-10 rounded-xl bg-[#f5f6f8] p-1">
                    <TabsTrigger value="table" className="gap-2 px-3"><FileSpreadsheet className="size-4" /> Table</TabsTrigger>
                    <TabsTrigger value="board" className="gap-2 px-3"><LayoutGrid className="size-4" /> Board</TabsTrigger>
                    <TabsTrigger value="gantt" className="gap-2 px-3"><BarChart3 className="size-4" /> Gantt</TabsTrigger>
                    <TabsTrigger value="calendar" className="gap-2 px-3"><CalendarDays className="size-4" /> Calendar</TabsTrigger>
                    <TabsTrigger value="dashboard" className="gap-2 px-3"><Gauge className="size-4" /> Dashboard</TabsTrigger>
                  </TabsList>
                </Tabs>
                <Button onClick={() => addTask(null)} className="gap-2 bg-[#0073ea] text-white hover:bg-[#0060b9]"><Plus className="size-4" /> Add task</Button>
                {view === "table" && <Button variant="outline" onClick={() => setColumnDialogOpen(true)} className="gap-2"><Columns3 className="size-4" /> Add column</Button>}
                {(view === "table" || view === "gantt") && parentTaskIds.length > 0 && <Button variant="outline" onClick={() => setCollapsed(allTasksCollapsed ? new Set() : new Set(parentTaskIds))}>{allTasksCollapsed ? "Expand all" : "Collapse all"}</Button>}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[190px] flex-1 xl:w-60 xl:flex-none">
                  <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
                  <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tasks or owners" className="h-10 pl-9" />
                  {search && <button type="button" onClick={() => setSearch("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700" aria-label="Clear search"><X className="size-4" /></button>}
                </div>
                <Select value={priorityFilter} onValueChange={(value) => setPriorityFilter(value as Priority | "All")}>
                  <SelectTrigger className="h-10 w-[142px]"><Filter className="mr-1 size-4 text-slate-400" /><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All priorities</SelectItem>
                    {priorityOrder.map((priority) => <SelectItem key={priority} value={priority}>{priority}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={taskFocus} onValueChange={(value) => setTaskFocus(value as TaskFocus)}>
                  <SelectTrigger className="h-10 w-[148px]"><Clock3 className="mr-1 size-4 text-slate-400" /><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All work</SelectItem>
                    <SelectItem value="open">Open work</SelectItem>
                    <SelectItem value="due-soon">Due in 14 days</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                    <SelectItem value="blocked">Blocked / waiting</SelectItem>
                    <SelectItem value="done">Completed</SelectItem>
                  </SelectContent>
                </Select>
                {(search || priorityFilter !== "All" || taskFocus !== "all") && <Button variant="ghost" className="h-10 px-3 text-slate-500" onClick={() => { setSearch(""); setPriorityFilter("All"); setTaskFocus("all"); }}>Clear</Button>}
                {view === "gantt" && (
                  <Select value={String(weekWidth)} onValueChange={(value) => setWeekWidth(Number(value))}>
                    <SelectTrigger className="h-10 w-[116px]"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="48">Compact</SelectItem><SelectItem value="72">Comfort</SelectItem><SelectItem value="104">Detailed</SelectItem></SelectContent>
                  </Select>
                )}
              </div>
            </div>

            <div ref={workspaceRef} className="bg-white">
              {view === "table" && <TableWorkspace project={activeProject} tasks={visibleTasks} collapsed={collapsed} setCollapsed={setCollapsed} openTask={openTask} addTask={addTask} setTaskToDelete={setTaskToDelete} moveTask={moveTask} extendTask={extendTask} duplicateTask={duplicateTask} updateTask={updateTask} />}
              {view === "board" && <BoardWorkspace project={activeProject} tasks={visibleTasks} openTask={openTask} addTask={addTask} changeTaskStatus={changeTaskStatus} />}
              {view === "gantt" && <GanttWorkspace project={activeProject} tasks={visibleTasks} collapsed={collapsed} setCollapsed={setCollapsed} openTask={openTask} addTask={addTask} weekWidth={weekWidth} />}
              {view === "calendar" && <CalendarWorkspace project={activeProject} tasks={visibleTasks} openTask={openTask} shiftTaskToDate={shiftTaskToDate} />}
              {view === "dashboard" && <DashboardWorkspace project={activeProject} widgets={activeProject.dashboardWidgets ?? defaultDashboardWidgets} setWidgets={setDashboardWidgets} />}
            </div>
          </section>
        </div>
      </main>

      <TaskEditor
        project={activeProject}
        draft={taskDraft}
        editingTaskId={editingTaskId}
        setDraft={setTaskDraft}
        onClose={() => { setTaskDraft(null); setEditingTaskId(null); }}
        onSave={saveTask}
        onDelete={() => taskDraft && setTaskToDelete(activeProject.tasks.find((task) => task.id === taskDraft.id) ?? null)}
      />

      {presentationOpen && <ManagerView project={activeProject} onClose={() => setPresentationOpen(false)} />}

      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Share live manager view</DialogTitle><DialogDescription>Your manager can open this read-only, interactive Gantt from any laptop. Updates from this project are synchronized automatically.</DialogDescription></DialogHeader>
          <div className="py-2">
            {shareLoading && <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-4 text-sm text-slate-600"><span className="size-4 animate-spin rounded-full border-2 border-[#0073ea] border-t-transparent" /> Preparing the link…</div>}
            {!shareLoading && shareUrl && <div className="space-y-3"><div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-2"><Link2 className="ml-2 size-4 shrink-0 text-[#0073ea]" /><Input value={shareUrl} readOnly className="border-0 bg-transparent shadow-none focus-visible:ring-0" /><Button onClick={copyShareLink} size="sm"><Copy className="mr-2 size-4" /> Copy</Button></div><p className="text-xs leading-5 text-slate-500">Anyone with this hard-to-guess link can view the project. They cannot edit it.</p></div>}
            {!shareLoading && shareError && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700"><p>{shareError}</p></div>}
          </div>
          <DialogFooter>{shareUrl && <Button variant="outline" asChild><a href={shareUrl} target="_blank" rel="noreferrer"><ExternalLink className="mr-2 size-4" /> Open manager view</a></Button>}<Button variant="outline" onClick={() => setShareDialogOpen(false)}>Done</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={projectDialogOpen} onOpenChange={setProjectDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{projectDialogMode === "new" ? "Create a project" : "Project settings"}</DialogTitle><DialogDescription>{projectDialogMode === "new" ? "Start with a simple project board, then shape the plan in any view." : "Update the project details used across the workspace and exports."}</DialogDescription></DialogHeader>
          <div className="space-y-5 py-2">
            <Field label="Project name"><Input value={projectDraft.name} onChange={(event) => setProjectDraft((draft) => ({ ...draft, name: event.target.value }))} autoFocus /></Field>
            <Field label="Description"><textarea value={projectDraft.description} onChange={(event) => setProjectDraft((draft) => ({ ...draft, description: event.target.value }))} rows={3} className="w-full resize-none rounded-lg border border-input bg-transparent px-3 py-2 text-base outline-none focus-visible:ring-2 focus-visible:ring-ring" /></Field>
            <Field label="Project color"><ColorPicker value={projectDraft.color} onChange={(color) => setProjectDraft((draft) => ({ ...draft, color }))} /></Field>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setProjectDialogOpen(false)}>Cancel</Button><Button onClick={saveProject} className="bg-[#0073ea] hover:bg-[#0060b9]">{projectDialogMode === "new" ? "Create project" : "Save changes"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={teamDialogOpen} onOpenChange={setTeamDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>Project team</DialogTitle><DialogDescription>Add people once, then assign them as owners or supporters directly from the spreadsheet.</DialogDescription></DialogHeader>
          <div className="grid gap-5 py-2 sm:grid-cols-[1fr_240px]">
            <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
              {teamMembersForProject(activeProject).map((member) => (
                <div key={member.id} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3">
                  <Avatar size="lg"><AvatarImage src={member.avatarUrl} alt={member.name} /><AvatarFallback style={{ backgroundColor: `${member.color}22`, color: member.color }} className="font-bold">{initials(member.name)}</AvatarFallback></Avatar>
                  <div className="min-w-0"><p className="truncate text-sm font-bold">{member.name}</p><p className="truncate text-xs text-slate-500">{member.role}</p></div>
                </div>
              ))}
              {!teamMembersForProject(activeProject).length && <div className="grid min-h-36 place-items-center rounded-xl border border-dashed border-slate-200 text-sm text-slate-400">No team members yet</div>}
            </div>
            <div className="space-y-4 rounded-xl bg-slate-50 p-4">
              <Field label="Name"><Input value={memberDraft.name} onChange={(event) => setMemberDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Full name" /></Field>
              <Field label="Role"><Input value={memberDraft.role} onChange={(event) => setMemberDraft((draft) => ({ ...draft, role: event.target.value }))} placeholder="Project role" /></Field>
              <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-dashed border-slate-300 bg-white p-3 text-sm font-semibold text-slate-600 hover:border-[#0073ea] hover:text-[#0073ea]"><ImagePlus className="size-4" /><span className="min-w-0 truncate">{memberPhoto?.name ?? "Upload picture"}</span><input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => setMemberPhoto(event.target.files?.[0] ?? null)} /></label>
              <p className="text-[0.7rem] leading-4 text-slate-400">JPG, PNG, or WebP up to 2 MB. Photo upload requires sign-in.</p>
              <Button onClick={addTeamMember} disabled={memberUploading} className="w-full bg-[#0073ea] hover:bg-[#0060b9]">{memberUploading ? "Adding…" : "Add team member"}</Button>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setTeamDialogOpen(false)}>Done</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={columnDialogOpen} onOpenChange={setColumnDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Add spreadsheet column</DialogTitle><DialogDescription>Create a project-specific field that can be edited for every task and subtask.</DialogDescription></DialogHeader>
          <div className="space-y-5 py-2">
            <Field label="Column name"><Input value={columnDraft.name} onChange={(event) => setColumnDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Budget, risk, location…" autoFocus /></Field>
            <Field label="Column type"><Select value={columnDraft.type} onValueChange={(value) => setColumnDraft((draft) => ({ ...draft, type: value as CustomColumnType }))}><SelectTrigger className="w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="text">Text</SelectItem><SelectItem value="number">Number</SelectItem><SelectItem value="select">Dropdown</SelectItem><SelectItem value="date">Date</SelectItem><SelectItem value="checkbox">Checkbox</SelectItem></SelectContent></Select></Field>
            {columnDraft.type === "select" && <Field label="Dropdown options" hint="Comma-separated"><Input value={columnDraft.options} onChange={(event) => setColumnDraft((draft) => ({ ...draft, options: event.target.value }))} placeholder="Low, Medium, High" /></Field>}
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setColumnDialogOpen(false)}>Cancel</Button><Button onClick={addCustomColumn} className="bg-[#0073ea] hover:bg-[#0060b9]">Add column</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!taskToDelete} onOpenChange={(open) => !open && setTaskToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete “{taskToDelete?.name}”?</AlertDialogTitle><AlertDialogDescription>{taskToDelete && childrenOf(activeProject.tasks, taskToDelete.id).length ? "Its subtasks will also be deleted, and linked dependencies will be removed." : "This task will be removed, along with links to it from other tasks."}</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Keep task</AlertDialogCancel><AlertDialogAction onClick={confirmDeleteTask} className="bg-red-600 text-white hover:bg-red-700">Delete task</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={projectDeleteOpen} onOpenChange={setProjectDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete “{activeProject.name}”?</AlertDialogTitle><AlertDialogDescription>This removes the project and all of its tasks from this browser. Other projects will not be affected.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Keep project</AlertDialogCancel><AlertDialogAction onClick={deleteActiveProject} className="bg-red-600 text-white hover:bg-red-700">Delete project</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SummaryCard({ label, value, detail, icon, accent, progress }: { label: string; value: string; detail: string; icon: React.ReactNode; accent: string; progress?: number }) {
  return (
    <article className="rounded-xl border border-slate-200/80 bg-white px-3.5 py-3 shadow-[0_1px_2px_rgba(15,23,42,.03)] sm:px-4">
      <div className="flex items-center gap-3">
        <span className="grid size-8 shrink-0 place-items-center rounded-lg" style={{ backgroundColor: `${accent}12`, color: accent }}>{icon}</span>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-2"><span className="truncate text-xs font-medium text-slate-500">{label}</span><strong className="text-xl font-semibold tracking-tight text-slate-900">{value}</strong></div>
          <div className="mt-0.5 truncate text-xs text-slate-400">{detail}</div>
        </div>
      </div>
      {progress !== undefined && <Progress value={progress} className="mt-2.5 h-1" style={{ "--primary": accent } as React.CSSProperties} />}
    </article>
  );
}

function TableWorkspace({ project, tasks, collapsed, setCollapsed, openTask, addTask, setTaskToDelete, moveTask, extendTask, duplicateTask, updateTask }: { project: Project; tasks: Task[]; collapsed: Set<string>; setCollapsed: React.Dispatch<React.SetStateAction<Set<string>>>; openTask: (task: Task) => void; addTask: (parentId: string | null) => void; setTaskToDelete: (task: Task) => void; moveTask: (taskId: string, direction: -1 | 1) => void; extendTask: (taskId: string, days: number) => void; duplicateTask: (taskId: string) => void; updateTask: (taskId: string, patch: Partial<Task>) => void }) {
  const team = teamMembersForProject(project);
  const owners = Array.from(new Set(["Unassigned", ...team.map((member) => member.name), ...project.tasks.map((task) => task.owner)]));
  return (
    <div className="overflow-x-auto">
      <Table className="min-w-[1480px]">
        <TableHeader><TableRow className="bg-slate-50/90 hover:bg-slate-50/90"><TableHead className="sticky left-0 z-10 w-10 bg-slate-50" /><TableHead className="sticky left-10 z-10 min-w-72 bg-slate-50">Task</TableHead><TableHead className="min-w-44">Owner</TableHead><TableHead className="min-w-44">Supported by</TableHead><TableHead className="min-w-36">Start</TableHead><TableHead className="min-w-36">End</TableHead><TableHead className="min-w-40">Status</TableHead><TableHead className="min-w-36">Priority</TableHead><TableHead className="min-w-32">Progress</TableHead><TableHead>Dependencies</TableHead>{(project.customColumns ?? []).map((column) => <TableHead key={column.id} className="min-w-40">{column.name}</TableHead>)}<TableHead className="w-12" /></TableRow></TableHeader>
        <TableBody>
          {tasks.map((task) => {
            const children = childrenOf(project.tasks, task.id);
            const depth = getTaskDepth(task, project.tasks);
            const siblings = project.tasks.filter((candidate) => candidate.parentId === task.parentId);
            const siblingIndex = siblings.findIndex((candidate) => candidate.id === task.id);
            const support = task.supportedBy ?? [];
            return (
              <TableRow key={task.id} className={`group ${task.parentId ? "bg-white" : "bg-[#fafbfc]"} hover:bg-[#f5f9ff]`}>
                <TableCell className="sticky left-0 z-[2] bg-inherit pr-0"><div className="flex flex-col"><button type="button" disabled={siblingIndex === 0} onClick={() => moveTask(task.id, -1)} className="rounded p-0.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-20" aria-label={`Move ${task.name} up`}><ArrowUp className="size-3.5" /></button><button type="button" disabled={siblingIndex === siblings.length - 1} onClick={() => moveTask(task.id, 1)} className="rounded p-0.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-20" aria-label={`Move ${task.name} down`}><ArrowDown className="size-3.5" /></button></div></TableCell>
                <TableCell className="sticky left-10 z-[2] bg-inherit shadow-[6px_0_12px_rgba(31,41,55,.025)]">
                  <div className="flex items-center" style={{ paddingLeft: `${depth * 22}px` }}>
                    {children.length ? <button type="button" onClick={() => setCollapsed((current) => { const next = new Set(current); if (next.has(task.id)) next.delete(task.id); else next.add(task.id); return next; })} className="mr-1 rounded p-0.5 text-slate-400 hover:bg-slate-100">{collapsed.has(task.id) ? <ChevronRight className="size-4" /> : <ChevronDown className="size-4" />}</button> : <span className="mr-2 size-3" />}
                    <span className="mr-2 size-2.5 shrink-0 rounded-full" style={{ backgroundColor: task.color }} />
                    <Input value={task.name} onChange={(event) => updateTask(task.id, { name: event.target.value })} className={`h-8 min-w-36 border-transparent bg-transparent px-2 shadow-none hover:border-slate-200 focus-visible:border-[#0073ea] ${!task.parentId ? "font-bold" : "font-medium"}`} aria-label={`Task name for ${task.name}`} />
                    {!task.parentId && <button type="button" onClick={() => addTask(task.id)} className="ml-1 hidden shrink-0 rounded-md px-2 py-1 text-xs font-semibold text-[#0073ea] hover:bg-blue-50 group-hover:inline-flex">+ subtask</button>}
                  </div>
                </TableCell>
                <TableCell><Select value={task.owner} onValueChange={(owner) => updateTask(task.id, { owner })}><SelectTrigger className="h-8 w-full border-transparent bg-transparent shadow-none hover:border-slate-200"><SelectValue /></SelectTrigger><SelectContent>{owners.map((owner) => <SelectItem key={owner} value={owner}>{owner}</SelectItem>)}</SelectContent></Select></TableCell>
                <TableCell>
                  <DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" className="h-8 w-full justify-start overflow-hidden border-transparent bg-transparent px-2 font-normal shadow-none hover:border-slate-200 hover:bg-white"><span className="truncate">{support.length ? support.join(", ") : "Add support"}</span><ChevronDown className="ml-auto size-3.5 shrink-0 text-slate-400" /></Button></DropdownMenuTrigger><DropdownMenuContent className="w-56"><DropdownMenuLabel>Supported by</DropdownMenuLabel>{team.map((member) => <DropdownMenuCheckboxItem key={member.id} checked={support.includes(member.name)} onCheckedChange={(checked) => updateTask(task.id, { supportedBy: checked ? [...support, member.name] : support.filter((name) => name !== member.name) })}>{member.name}</DropdownMenuCheckboxItem>)}{!team.length && <DropdownMenuItem disabled>Add people from Team first</DropdownMenuItem>}</DropdownMenuContent></DropdownMenu>
                </TableCell>
                <TableCell><Input type="date" value={task.start} onChange={(event) => updateTask(task.id, { start: event.target.value })} className="h-8 border-transparent bg-transparent px-2 shadow-none hover:border-slate-200" /></TableCell>
                <TableCell><Input type="date" value={task.end} onChange={(event) => updateTask(task.id, { end: event.target.value })} className="h-8 border-transparent bg-transparent px-2 shadow-none hover:border-slate-200" /></TableCell>
                <TableCell><Select value={task.status} onValueChange={(status) => updateTask(task.id, { status: status as TaskStatus })}><SelectTrigger className={`h-8 w-full border-0 shadow-none ${statusStyles[task.status]}`}><SelectValue /></SelectTrigger><SelectContent>{statusOrder.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></TableCell>
                <TableCell><Select value={task.priority} onValueChange={(priority) => updateTask(task.id, { priority: priority as Priority })}><SelectTrigger className={`h-8 w-full border-0 shadow-none ring-1 ring-inset ${priorityStyles[task.priority]}`}><SelectValue /></SelectTrigger><SelectContent>{priorityOrder.map((priority) => <SelectItem key={priority} value={priority}>{priority}</SelectItem>)}</SelectContent></Select></TableCell>
                <TableCell><Select value={String(task.progress)} onValueChange={(progress) => updateTask(task.id, { progress: Number(progress) })}><SelectTrigger className="h-8 w-full border-transparent bg-transparent shadow-none hover:border-slate-200"><SelectValue /></SelectTrigger><SelectContent>{Array.from(new Set([task.progress, ...Array.from({ length: 11 }, (_, index) => index * 10)])).sort((a, b) => a - b).map((progress) => <SelectItem key={progress} value={String(progress)}>{progress}%</SelectItem>)}</SelectContent></Select></TableCell>
                <TableCell><DependencyCell task={task} project={project} /></TableCell>
                {(project.customColumns ?? []).map((column) => <TableCell key={column.id}><CustomFieldCell column={column} value={task.customFields?.[column.id]} onChange={(value) => updateTask(task.id, { customFields: { ...(task.customFields ?? {}), [column.id]: value } })} /></TableCell>)}
                <TableCell><DropdownMenu><DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="size-8 opacity-0 group-hover:opacity-100" aria-label={`Actions for ${task.name}`}><MoreHorizontal className="size-4" /></Button></DropdownMenuTrigger><DropdownMenuContent align="end"><DropdownMenuItem onClick={() => openTask(task)}>Open full editor</DropdownMenuItem>{!task.parentId && <DropdownMenuItem onClick={() => addTask(task.id)}>Add subtask</DropdownMenuItem>}<DropdownMenuItem onClick={() => duplicateTask(task.id)}><Copy className="size-4" /> Duplicate task</DropdownMenuItem>{task.status !== "Done" && <DropdownMenuItem onClick={() => updateTask(task.id, { status: "Done", progress: 100 })}><Check className="size-4" /> Mark done</DropdownMenuItem>}<DropdownMenuSeparator /><DropdownMenuItem onClick={() => extendTask(task.id, 1)}>Add 1 day</DropdownMenuItem><DropdownMenuItem onClick={() => extendTask(task.id, 5)}>Add 5 days</DropdownMenuItem><DropdownMenuSeparator /><DropdownMenuItem onClick={() => setTaskToDelete(task)} className="text-red-600">Delete</DropdownMenuItem></DropdownMenuContent></DropdownMenu></TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      {!tasks.length && <EmptyTasks />}
      <div className="border-t border-slate-200 bg-slate-50 px-4 py-2 text-xs text-slate-500">Table view · changes are saved automatically in this browser.</div>
    </div>
  );
}

function CustomFieldCell({ column, value, onChange }: { column: CustomColumn; value: string | number | boolean | undefined; onChange: (value: string | number | boolean) => void }) {
  if (column.type === "checkbox") return <div className="flex justify-center"><Checkbox checked={Boolean(value)} onCheckedChange={(checked) => onChange(Boolean(checked))} /></div>;
  if (column.type === "select") return <Select value={String(value ?? "")} onValueChange={onChange}><SelectTrigger className="h-8 w-full border-transparent bg-transparent shadow-none hover:border-slate-200"><SelectValue placeholder="Choose…" /></SelectTrigger><SelectContent>{(column.options ?? []).map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent></Select>;
  return <Input type={column.type === "number" ? "number" : column.type === "date" ? "date" : "text"} value={String(value ?? "")} onChange={(event) => onChange(column.type === "number" ? Number(event.target.value) : event.target.value)} className="h-8 border-transparent bg-transparent shadow-none hover:border-slate-200" />;
}

function BoardWorkspace({ project, tasks, openTask, addTask, changeTaskStatus }: { project: Project; tasks: Task[]; openTask: (task: Task) => void; addTask: (parentId: string | null, initial?: Partial<Task>) => void; changeTaskStatus: (taskId: string, status: TaskStatus) => void }) {
  const leafTasks = tasks.filter((task) => !childrenOf(project.tasks, task.id).length);
  return (
    <div className="overflow-x-auto bg-[#f7f8fa] p-4 sm:p-5">
      <div className="grid min-w-[980px] grid-cols-4 gap-4">
        {statusOrder.map((status) => {
          const columnTasks = leafTasks.filter((task) => task.status === status);
          return (
            <section key={status} className="rounded-2xl border border-slate-200/90 bg-white p-3 shadow-[0_1px_2px_rgba(15,23,42,.03)]" onDragOver={(event) => event.preventDefault()} onDrop={(event) => { const taskId = event.dataTransfer.getData("text/task-id"); if (taskId) changeTaskStatus(taskId, status); }}>
              <header className="mb-3 flex items-center justify-between px-1"><div className="flex items-center gap-2"><span className={`size-2.5 rounded-full ${status === "Done" ? "bg-emerald-500" : status === "Blocked" ? "bg-red-500" : status === "In progress" ? "bg-blue-500" : "bg-slate-400"}`} /><h3 className="text-sm font-bold">{status}</h3><span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-500">{columnTasks.length}</span></div><Button variant="ghost" size="icon" className="size-7" onClick={() => addTask(null, { status, progress: status === "Done" ? 100 : 0 })} aria-label={`Add task to ${status}`}><Plus className="size-4" /></Button></header>
              <div className="min-h-[330px] space-y-3">
                {columnTasks.map((task) => {
                  const parent = project.tasks.find((candidate) => candidate.id === task.parentId);
                  return (
                    <button key={task.id} type="button" draggable onDragStart={(event) => event.dataTransfer.setData("text/task-id", task.id)} onClick={() => openTask(task)} className="block w-full cursor-grab rounded-xl border border-slate-200/90 bg-white p-3 text-left shadow-sm transition hover:border-slate-300 hover:shadow-md active:cursor-grabbing">
                      <div className="mb-3 flex items-start justify-between gap-2"><span className="rounded-md bg-slate-100 px-1.5 py-1 font-mono text-[0.68rem] text-slate-500">{compactId(task.id)}</span><PriorityBadge priority={task.priority} /></div>
                      <h4 className="text-sm font-bold leading-5">{task.name}</h4>
                      {parent && <p className="mt-1 truncate text-xs text-slate-400">{parent.name}</p>}
                      <div className="mt-4 flex items-center justify-between text-xs text-slate-500"><span className="flex items-center gap-1.5"><Clock3 className="size-3.5" /> {formatDate(task.end)}</span><span className="rounded-full bg-slate-100 px-2 py-1 font-semibold">{task.owner}</span></div>
                      <div className="mt-3 flex items-center gap-2"><Progress value={task.progress} className="h-1.5" /><span className="text-xs tabular-nums text-slate-500">{task.progress}%</span></div>
                      {task.dependencies.length > 0 && <div className={`mt-3 flex items-center gap-1.5 text-xs font-medium ${taskHasUnfinishedDependency(task, project.tasks) ? "text-orange-600" : "text-emerald-600"}`}><ListTree className="size-3.5" /> {task.dependencies.length} dependenc{task.dependencies.length === 1 ? "y" : "ies"}</div>}
                    </button>
                  );
                })}
                {!columnTasks.length && <div className="grid min-h-28 place-items-center rounded-lg border border-dashed border-slate-200 text-xs text-slate-400">Drop tasks here</div>}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function CalendarWorkspace({ project, tasks, openTask, shiftTaskToDate }: { project: Project; tasks: Task[]; openTask: (task: Task) => void; shiftTaskToDate: (taskId: string, start: string) => void }) {
  const initial = project.tasks[0]?.start ?? new Date().toISOString().slice(0, 10);
  const [month, setMonth] = useState(initial.slice(0, 7));
  const monthDate = new Date(`${month}-01T00:00:00Z`);
  const first = monthDate.toISOString().slice(0, 10);
  const gridStart = addDays(first, -monthDate.getUTCDay());
  const days = Array.from({ length: 42 }, (_, index) => addDays(gridStart, index));
  const changeMonth = (offset: number) => {
    const next = new Date(Date.UTC(monthDate.getUTCFullYear(), monthDate.getUTCMonth() + offset, 1));
    setMonth(next.toISOString().slice(0, 7));
  };
  return (
    <div className="bg-white p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div><h3 className="text-lg font-bold">{monthDate.toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" })}</h3><p className="text-xs text-slate-500">Drag a task to a new day to move it without changing its duration.</p></div>
        <div className="flex gap-2"><Button variant="outline" size="icon" onClick={() => changeMonth(-1)} aria-label="Previous month"><ChevronLeft className="size-4" /></Button><Button variant="outline" onClick={() => setMonth(new Date().toISOString().slice(0, 7))}>Today</Button><Button variant="outline" size="icon" onClick={() => changeMonth(1)} aria-label="Next month"><ChevronRight className="size-4" /></Button></div>
      </div>
      <div className="grid min-w-[760px] grid-cols-7 overflow-hidden rounded-xl border border-slate-200">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((label, index) => <div key={label} className={`border-b border-r border-slate-200 px-3 py-2 text-xs font-bold uppercase tracking-[0.1em] last:border-r-0 ${[5, 6].includes(index) ? "bg-slate-100 text-slate-500" : "bg-slate-50 text-slate-600"}`}>{label}</div>)}
        {days.map((day, index) => {
          const date = new Date(`${day}T00:00:00Z`);
          const inMonth = day.slice(0, 7) === month;
          const weekend = [5, 6].includes(date.getUTCDay());
          const starting = tasks.filter((task) => task.start === day);
          return (
            <div key={day} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { const taskId = event.dataTransfer.getData("text/task-id"); if (taskId) shiftTaskToDate(taskId, day); }} className={`min-h-28 border-b border-r border-slate-200 p-2 ${index % 7 === 6 ? "border-r-0" : ""} ${weekend ? "bg-slate-50" : "bg-white"} ${!inMonth ? "opacity-45" : ""}`}>
              <div className="mb-1 flex items-center justify-between"><span className={`grid size-6 place-items-center rounded-full text-xs font-semibold ${day === new Date().toISOString().slice(0, 10) ? "bg-[#0073ea] text-white" : "text-slate-500"}`}>{date.getUTCDate()}</span>{weekend && <span className="text-[0.6rem] font-bold uppercase text-slate-400">Weekend</span>}</div>
              <div className="space-y-1">
                {starting.slice(0, 3).map((task) => <button key={task.id} type="button" draggable onDragStart={(event) => event.dataTransfer.setData("text/task-id", task.id)} onClick={() => openTask(task)} className="block w-full cursor-grab truncate rounded-md px-2 py-1 text-left text-[0.7rem] font-semibold text-white shadow-sm active:cursor-grabbing" style={{ backgroundColor: task.color }} title={`${task.name} · ${taskDuration(task)} days`}>{task.name}</button>)}
                {starting.length > 3 && <span className="block px-1 text-[0.68rem] font-semibold text-slate-400">+{starting.length - 3} more</span>}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-slate-500">Weekend days are configured as Friday and Saturday.</p>
    </div>
  );
}

const dashboardWidgetLabels: Record<DashboardWidgetId, string> = {
  progress: "Progress snapshot",
  status: "Tasks by status",
  priority: "Priority mix",
  owners: "Owner workload",
  deadlines: "Upcoming deadlines",
};

function DashboardWorkspace({ project, widgets, setWidgets }: { project: Project; widgets: DashboardWidgetId[]; setWidgets: (widgets: DashboardWidgetId[]) => void }) {
  const leafTasks = project.tasks.filter((task) => !project.tasks.some((candidate) => candidate.parentId === task.id));
  const progress = Math.round(leafTasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(1, leafTasks.length));
  const statusData = statusOrder.map((name) => ({ name, tasks: leafTasks.filter((task) => task.status === name).length }));
  const priorityData = priorityOrder.map((name, index) => ({ name, value: leafTasks.filter((task) => task.priority === name).length, fill: ["#ef4444", "#f97316", "#367bf5", "#94a3b8"][index] })).filter((item) => item.value);
  const ownerData = Array.from(new Set(leafTasks.map((task) => task.owner))).map((name) => ({ name, tasks: leafTasks.filter((task) => task.owner === name).length })).sort((a, b) => b.tasks - a.tasks).slice(0, 8);
  const deadlines = [...leafTasks].filter((task) => task.status !== "Done").sort((a, b) => a.end.localeCompare(b.end)).slice(0, 6);
  const moveWidget = (id: DashboardWidgetId, direction: -1 | 1) => {
    const index = widgets.indexOf(id);
    const target = index + direction;
    if (target < 0 || target >= widgets.length) return;
    const next = [...widgets];
    [next[index], next[target]] = [next[target], next[index]];
    setWidgets(next);
  };
  const widgetContent: Record<DashboardWidgetId, React.ReactNode> = {
    progress: <div className="grid h-56 place-items-center"><div className="text-center"><div className="relative mx-auto grid size-36 place-items-center rounded-full" style={{ background: `conic-gradient(${project.color} ${progress * 3.6}deg, #e9ecf2 0)` }}><div className="grid size-28 place-items-center rounded-full bg-white"><div><span className="block text-4xl font-bold tracking-tight">{progress}%</span><span className="text-xs font-semibold text-slate-400">overall progress</span></div></div></div><p className="mt-4 text-sm text-slate-500">{leafTasks.filter((task) => task.status === "Done").length} of {leafTasks.length} actionable tasks complete</p></div></div>,
    status: <ChartContainer config={{ tasks: { label: "Tasks", color: "#0073ea" } }} className="h-56 w-full aspect-auto"><BarChart data={statusData} margin={{ left: 0, right: 8 }}><CartesianGrid vertical={false} /><XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={10} /><YAxis allowDecimals={false} tickLine={false} axisLine={false} width={24} /><ChartTooltip content={<ChartTooltipContent />} /><Bar dataKey="tasks" fill="var(--color-tasks)" radius={[5, 5, 0, 0]} /></BarChart></ChartContainer>,
    priority: <ChartContainer config={{ value: { label: "Tasks", color: "#0073ea" } }} className="h-56 w-full aspect-auto"><PieChart><ChartTooltip content={<ChartTooltipContent nameKey="name" />} /><Pie data={priorityData} dataKey="value" nameKey="name" innerRadius={52} outerRadius={82} paddingAngle={3}>{priorityData.map((item) => <Cell key={item.name} fill={item.fill} />)}</Pie></PieChart></ChartContainer>,
    owners: <ChartContainer config={{ tasks: { label: "Tasks", color: "#0f9f80" } }} className="h-56 w-full aspect-auto"><BarChart data={ownerData} layout="vertical" margin={{ left: 12, right: 12 }}><CartesianGrid horizontal={false} /><XAxis type="number" allowDecimals={false} tickLine={false} axisLine={false} /><YAxis dataKey="name" type="category" tickLine={false} axisLine={false} width={86} fontSize={10} /><ChartTooltip content={<ChartTooltipContent />} /><Bar dataKey="tasks" fill="var(--color-tasks)" radius={[0, 5, 5, 0]} /></BarChart></ChartContainer>,
    deadlines: <div className="divide-y divide-slate-100">{deadlines.map((task) => <div key={task.id} className="flex items-center gap-3 py-3"><span className="size-2.5 shrink-0 rounded-full" style={{ backgroundColor: task.color }} /><span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{task.name}</span><span className="text-xs text-slate-400">{task.owner}</span></span><span className="text-right text-xs font-semibold text-slate-600">{formatDate(task.end, { day: "numeric", month: "short", year: "numeric" })}</span></div>)}{!deadlines.length && <div className="grid h-48 place-items-center text-sm text-slate-400">No open deadlines</div>}</div>,
  };
  return (
    <div className="bg-slate-50/70 p-4 sm:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h3 className="text-lg font-bold">Management dashboard</h3><p className="text-xs text-slate-500">A live executive view built from the current project plan.</p></div><DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" className="gap-2 bg-white"><Settings2 className="size-4" /> Customize dashboard</Button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-56"><DropdownMenuLabel>Visible widgets</DropdownMenuLabel>{defaultDashboardWidgets.map((widget) => <DropdownMenuCheckboxItem key={widget} checked={widgets.includes(widget)} onCheckedChange={(checked) => setWidgets(checked ? [...widgets, widget] : widgets.filter((item) => item !== widget))}>{dashboardWidgetLabels[widget]}</DropdownMenuCheckboxItem>)}</DropdownMenuContent></DropdownMenu></div>
      <div className="grid gap-4 xl:grid-cols-2">
        {widgets.map((widget, index) => <article key={widget} className={`rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_6px_24px_rgba(31,41,55,.04)] ${widget === "deadlines" ? "xl:col-span-2" : ""}`}><header className="mb-3 flex items-center justify-between"><h4 className="text-sm font-bold">{dashboardWidgetLabels[widget]}</h4><div className="flex"><Button variant="ghost" size="icon" className="size-7" disabled={index === 0} onClick={() => moveWidget(widget, -1)} aria-label={`Move ${dashboardWidgetLabels[widget]} earlier`}><ChevronLeft className="size-3.5" /></Button><Button variant="ghost" size="icon" className="size-7" disabled={index === widgets.length - 1} onClick={() => moveWidget(widget, 1)} aria-label={`Move ${dashboardWidgetLabels[widget]} later`}><ChevronRight className="size-3.5" /></Button></div></header>{widgetContent[widget]}</article>)}
        {!widgets.length && <div className="xl:col-span-2 grid min-h-72 place-items-center rounded-2xl border border-dashed border-slate-300 bg-white text-center"><div><Gauge className="mx-auto size-8 text-slate-300" /><p className="mt-2 font-semibold">Your dashboard is empty</p><p className="text-sm text-slate-400">Use Customize dashboard to add widgets.</p></div></div>}
      </div>
    </div>
  );
}

function GanttWorkspace({ project, tasks, collapsed, setCollapsed, openTask, addTask, weekWidth }: { project: Project; tasks: Task[]; collapsed: Set<string>; setCollapsed: React.Dispatch<React.SetStateAction<Set<string>>>; openTask: (task: Task) => void; addTask: (parentId: string | null) => void; weekWidth: number }) {
  const { start, count } = timelineBounds(project.tasks);
  const labelWidth = 320;
  const rowHeight = 48;
  const headerHeight = 72;
  const chartWidth = count * weekWidth;
  const totalWidth = labelWidth + chartWidth;
  const today = new Date().toISOString().slice(0, 10);
  const todayX = ((dateMs(today) - dateMs(start)) / (7 * DAY)) * weekWidth;
  const taskIndex = new Map(tasks.map((task, index) => [task.id, index]));

  return (
    <div className="max-h-[660px] overflow-auto bg-white gantt-scroll">
      <div className="relative" style={{ width: totalWidth, minHeight: headerHeight + Math.max(1, tasks.length) * rowHeight }}>
        <div className="sticky top-0 z-10 flex border-b border-slate-200 bg-white" style={{ width: totalWidth, height: headerHeight }}>
          <div className="sticky left-0 z-30 flex w-80 shrink-0 items-center border-r border-slate-200 bg-slate-50 px-4 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Task & owner</div>
          <div className="relative flex" style={{ width: chartWidth }}>
            {Array.from({ length: count }, (_, index) => {
              const weekStart = addDays(start, index * 7);
              const monthChanged = index === 0 || new Date(`${weekStart}T00:00:00Z`).getUTCMonth() !== new Date(`${addDays(weekStart, -7)}T00:00:00Z`).getUTCMonth();
              return <div key={weekStart} className={`relative shrink-0 border-r border-slate-200 px-2 pt-8 text-xs text-slate-500 ${monthChanged ? "bg-blue-50/45" : "bg-white"}`} style={{ width: weekWidth }}><span className="font-semibold">{formatDate(weekStart)}</span>{monthChanged && <span className="absolute left-2 top-2 text-[0.7rem] font-bold uppercase tracking-[0.12em] text-slate-700">{formatDate(weekStart, { month: "long", year: "numeric" })}</span>}</div>;
            })}
          </div>
        </div>

        <div className="relative flex" style={{ width: totalWidth, height: Math.max(1, tasks.length) * rowHeight }}>
          <div className="sticky left-0 z-20 w-80 shrink-0 border-r border-slate-200 bg-white shadow-[8px_0_16px_rgba(31,41,55,.03)]">
            {tasks.map((task) => {
              const children = childrenOf(project.tasks, task.id);
              const depth = getTaskDepth(task, project.tasks);
              return (
                <div key={task.id} className="group flex items-center border-b border-slate-100 px-3 hover:bg-slate-50" style={{ height: rowHeight }}>
                  <div className="flex min-w-0 flex-1 items-center" style={{ paddingLeft: depth * 18 }}>
                    {children.length ? <button type="button" onClick={() => setCollapsed((current) => { const next = new Set(current); if (next.has(task.id)) next.delete(task.id); else next.add(task.id); return next; })} className="mr-1 rounded p-1 text-slate-400 hover:bg-slate-100">{collapsed.has(task.id) ? <ChevronRight className="size-4" /> : <ChevronDown className="size-4" />}</button> : <span className="mr-2 w-4" />}
                    <span className="mr-2.5 size-2.5 shrink-0 rounded-full" style={{ backgroundColor: task.color }} />
                    <button type="button" onClick={() => openTask(task)} className="min-w-0 flex-1 text-left"><span className={`block truncate text-sm ${!task.parentId ? "font-bold" : "font-medium"}`}>{task.name}</span><span className="block truncate text-[0.7rem] text-slate-400">{task.owner}</span></button>
                    {!task.parentId && <button type="button" onClick={() => addTask(task.id)} className="hidden rounded p-1 text-[#0073ea] hover:bg-blue-50 group-hover:block" aria-label={`Add subtask to ${task.name}`}><Plus className="size-4" /></button>}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="relative" style={{ width: chartWidth, height: Math.max(1, tasks.length) * rowHeight, backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${weekWidth - 1}px, #e8ebf1 ${weekWidth - 1}px, #e8ebf1 ${weekWidth}px), repeating-linear-gradient(to bottom, transparent 0, transparent ${rowHeight - 1}px, #f0f2f6 ${rowHeight - 1}px, #f0f2f6 ${rowHeight}px)` }}>
            {todayX >= 0 && todayX <= chartWidth && <div className="absolute inset-y-0 z-[3] w-px bg-red-400" style={{ left: todayX }}><span className="absolute -top-6 -translate-x-1/2 rounded bg-red-500 px-1.5 py-0.5 text-[0.62rem] font-bold uppercase tracking-wide text-white">Today</span></div>}
            <svg className="pointer-events-none absolute inset-0 z-[1] overflow-visible" width={chartWidth} height={tasks.length * rowHeight} aria-hidden="true">
              <defs><marker id="dep-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="#aeb6c5" /></marker></defs>
              {tasks.flatMap((task, index) => task.dependencies.map((dependencyId) => {
                const dependency = project.tasks.find((candidate) => candidate.id === dependencyId);
                const dependencyRow = taskIndex.get(dependencyId);
                if (!dependency || dependencyRow === undefined) return null;
                const x1 = ((dateMs(dependency.end) - dateMs(start)) / (7 * DAY)) * weekWidth + weekWidth / 7;
                const x2 = ((dateMs(task.start) - dateMs(start)) / (7 * DAY)) * weekWidth;
                const y1 = dependencyRow * rowHeight + rowHeight / 2;
                const y2 = index * rowHeight + rowHeight / 2;
                const bend = x2 > x1 + 24 ? (x1 + x2) / 2 : Math.max(x1, x2) + 18;
                return <path key={`${task.id}-${dependencyId}`} d={`M ${x1} ${y1} H ${bend} V ${y2} H ${x2 - 6}`} fill="none" stroke="#aeb6c5" strokeWidth="1.15" markerEnd="url(#dep-arrow)" />;
              }))}
            </svg>
            {tasks.map((task, index) => {
              const left = ((dateMs(task.start) - dateMs(start)) / (7 * DAY)) * weekWidth;
              const width = Math.max(18, (taskDuration(task) / 7) * weekWidth);
              const isParent = childrenOf(project.tasks, task.id).length > 0;
              return (
                <button key={task.id} type="button" onClick={() => openTask(task)} className="group absolute z-[4] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0073ea] focus-visible:ring-offset-2" style={{ left, top: index * rowHeight + (isParent ? 12 : 10), width, height: isParent ? 24 : 28 }} aria-label={`${task.name}, ${formatDate(task.start)} to ${formatDate(task.end)}`}>
                  <span className={`absolute inset-0 overflow-hidden shadow-sm transition group-hover:-translate-y-0.5 group-hover:shadow-md ${isParent ? "rounded-md" : "rounded-lg"}`} style={{ backgroundColor: task.color }}>
                    <span className="absolute inset-y-0 left-0 bg-black/15" style={{ width: `${task.progress}%` }} />
                    {width >= 92 && <span className="relative block truncate px-2.5 py-1 text-[0.72rem] font-bold text-white drop-shadow-sm">{task.name}</span>}
                  </span>
                  {width < 92 && <span className="absolute left-[calc(100%+5px)] top-0 z-[5] whitespace-nowrap rounded-md bg-white px-1.5 py-1 text-[0.72rem] font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200/80">{task.name}</span>}
                </button>
              );
            })}
            {!tasks.length && <div className="absolute inset-0 grid place-items-center text-sm text-slate-400">No tasks match the current filters.</div>}
          </div>
        </div>
      </div>
      <div className="sticky bottom-0 left-0 z-30 flex w-full items-center justify-between border-t border-slate-200 bg-white/95 px-4 py-2 text-xs text-slate-500 backdrop-blur"><span>Bars show task duration; darker fill shows completed progress.</span><span className="hidden sm:inline">Dependency arrows connect prerequisite tasks.</span></div>
    </div>
  );
}

function TaskEditor({ project, draft, editingTaskId, setDraft, onClose, onSave, onDelete }: { project: Project; draft: TaskDraft | null; editingTaskId: string | null; setDraft: React.Dispatch<React.SetStateAction<TaskDraft | null>>; onClose: () => void; onSave: () => void; onDelete: () => void }) {
  if (!draft) return <Sheet open={false} />;
  const update = <K extends keyof TaskDraft>(key: K, value: TaskDraft[K]) => setDraft((current) => current ? { ...current, [key]: value } : current);
  const possibleParents = project.tasks.filter((task) => !task.parentId && task.id !== draft.id);
  const dependencyOptions = project.tasks.filter((task) => task.id !== draft.id && task.parentId !== draft.id);
  const team = teamMembersForProject(project);
  const owners = Array.from(new Set(["Unassigned", draft.owner, ...team.map((member) => member.name)]));
  const support = draft.supportedBy ?? [];
  return (
    <Sheet open={!!draft} onOpenChange={(open) => !open && onClose()}>
      <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-xl">
        <SheetHeader className="border-b border-slate-200 px-6 py-5"><SheetTitle>{editingTaskId ? "Edit task" : draft.parentId ? "Add subtask" : "Add task"}</SheetTitle><SheetDescription>{editingTaskId ? `Task ID ${draft.id}` : draft.parentId ? "The subtask will appear beneath its parent task." : "Create a top-level task. You can add subtasks later."}</SheetDescription></SheetHeader>
        <div className="space-y-5 px-6 py-6">
          <Field label="Task name"><Input value={draft.name} onChange={(event) => update("name", event.target.value)} autoFocus /></Field>
          <div className="grid grid-cols-2 gap-4"><Field label="Start date"><Input type="date" value={draft.start} onChange={(event) => update("start", event.target.value)} /></Field><Field label="End date"><Input type="date" value={draft.end} onChange={(event) => update("end", event.target.value)} /></Field></div>
          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3"><span className="mr-1 text-xs font-bold uppercase tracking-[0.1em] text-slate-500">Extend duration</span>{[1, 3, 5, 7].map((days) => <Button key={days} type="button" variant="outline" size="sm" onClick={() => update("end", addDays(draft.end, days))} className="bg-white">+{days} day{days === 1 ? "" : "s"}</Button>)}</div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Status"><Select value={draft.status} onValueChange={(value) => { update("status", value as TaskStatus); if (value === "Done") update("progress", 100); else if (draft.status === "Done" && draft.progress === 100) update("progress", value === "Not started" ? 0 : 50); }}><SelectTrigger className="w-full"><SelectValue /></SelectTrigger><SelectContent>{statusOrder.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></Field>
            <Field label="Priority"><Select value={draft.priority} onValueChange={(value) => update("priority", value as Priority)}><SelectTrigger className="w-full"><SelectValue /></SelectTrigger><SelectContent>{priorityOrder.map((priority) => <SelectItem key={priority} value={priority}>{priority}</SelectItem>)}</SelectContent></Select></Field>
          </div>
          <Field label="Owner"><Select value={draft.owner} onValueChange={(value) => update("owner", value)}><SelectTrigger className="w-full"><SelectValue /></SelectTrigger><SelectContent>{owners.map((owner) => <SelectItem key={owner} value={owner}>{owner}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Supported by" hint="Select one or more team members"><div className="rounded-xl border border-slate-200 p-2">{team.map((member) => <label key={member.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-slate-50"><Checkbox checked={support.includes(member.name)} onCheckedChange={(checked) => update("supportedBy", checked ? [...support, member.name] : support.filter((name) => name !== member.name))} /><Avatar size="sm"><AvatarImage src={member.avatarUrl} alt={member.name} /><AvatarFallback style={{ backgroundColor: `${member.color}22`, color: member.color }}>{initials(member.name)}</AvatarFallback></Avatar><span className="text-sm">{member.name}</span></label>)}{!team.length && <button type="button" onClick={() => toast.info("Open Team from the project header to add people.")} className="w-full rounded-lg px-3 py-4 text-center text-sm text-slate-400 hover:bg-slate-50">Add project team members first</button>}</div></Field>
          <Field label="Workstream"><Select value={draft.parentId ?? "none"} onValueChange={(value) => update("parentId", value === "none" ? null : value)}><SelectTrigger className="w-full"><SelectValue placeholder="Top-level workstream" /></SelectTrigger><SelectContent><SelectItem value="none">Top-level workstream</SelectItem>{possibleParents.map((task) => <SelectItem key={task.id} value={task.id}>{task.name}</SelectItem>)}</SelectContent></Select></Field>
          <Field label={`Progress · ${draft.progress}%`}><Slider value={[draft.progress]} max={100} step={5} onValueChange={(value) => update("progress", value[0])} /></Field>
          <Field label="Timeline color"><ColorPicker value={draft.color} onChange={(color) => update("color", color)} /></Field>
          <Field label="Dependencies" hint="Choose tasks that must finish first.">
            <div className="max-h-48 space-y-1 overflow-y-auto rounded-xl border border-slate-200 p-2">
              {dependencyOptions.map((task) => {
                const checked = draft.dependencies.includes(task.id);
                return <label key={task.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-slate-50"><Checkbox checked={checked} onCheckedChange={(value) => update("dependencies", value ? [...draft.dependencies, task.id] : draft.dependencies.filter((id) => id !== task.id))} /><span className="min-w-0 flex-1 truncate text-sm">{task.name}</span><span className="font-mono text-[0.68rem] text-slate-400">{compactId(task.id)}</span></label>;
              })}
              {!dependencyOptions.length && <p className="px-2 py-4 text-center text-sm text-slate-400">Add another task to create a dependency.</p>}
            </div>
          </Field>
          <Field label="Notes"><textarea value={draft.notes} onChange={(event) => update("notes", event.target.value)} rows={4} className="w-full resize-none rounded-lg border border-input bg-transparent px-3 py-2 text-base outline-none focus-visible:ring-2 focus-visible:ring-ring" placeholder="Scope, hand-off details, or risks" /></Field>
        </div>
        <div className="sticky bottom-0 flex items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
          {editingTaskId ? <Button variant="ghost" onClick={onDelete} className="text-red-600 hover:bg-red-50 hover:text-red-700"><Trash2 className="mr-2 size-4" /> Delete</Button> : <span />}
          <div className="flex gap-2"><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={onSave} className="bg-[#0073ea] hover:bg-[#0060b9]">Save task</Button></div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <label className="block space-y-2"><span className="flex items-baseline justify-between gap-3 text-sm font-semibold text-slate-700">{label}{hint && <span className="text-xs font-normal text-slate-400">{hint}</span>}</span>{children}</label>;
}

function ColorPicker({ value, onChange }: { value: string; onChange: (color: string) => void }) {
  return <div className="flex flex-wrap items-center gap-2">{palette.map((color) => <button key={color} type="button" onClick={() => onChange(color)} className="grid size-8 place-items-center rounded-full transition hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400 focus-visible:ring-offset-2" style={{ backgroundColor: color }} aria-label={`Use ${color}`}>{value.toLowerCase() === color && <Check className="size-4 text-white" />}</button>)}<label className="ml-1 flex h-9 items-center gap-2 rounded-lg border border-slate-200 px-2 text-xs font-medium text-slate-500"><input type="color" value={/^#[0-9a-f]{6}$/i.test(value) ? value : palette[0]} onChange={(event) => onChange(event.target.value)} className="size-5 cursor-pointer border-0 bg-transparent p-0" /> Custom</label></div>;
}

function PriorityBadge({ priority }: { priority: Priority }) {
  return <span className={`inline-flex rounded-full px-2 py-1 text-[0.68rem] font-bold ring-1 ring-inset ${priorityStyles[priority]}`}>{priority}</span>;
}

function DependencyCell({ task, project }: { task: Task; project: Project }) {
  if (!task.dependencies.length) return <span className="text-xs text-slate-400">None</span>;
  const waiting = taskHasUnfinishedDependency(task, project.tasks);
  return <span className={`inline-flex items-center gap-1.5 whitespace-nowrap text-xs font-semibold ${waiting ? "text-orange-600" : "text-emerald-600"}`}><ListTree className="size-3.5" />{task.dependencies.length} · {waiting ? "Waiting" : "Ready"}</span>;
}

function EmptyTasks() {
  return <div className="grid min-h-72 place-items-center p-8 text-center"><div><FolderKanban className="mx-auto size-9 text-slate-300" /><h3 className="mt-3 font-bold">No tasks found</h3><p className="mt-1 text-sm text-slate-500">Adjust the filters or add a new workstream.</p></div></div>;
}
