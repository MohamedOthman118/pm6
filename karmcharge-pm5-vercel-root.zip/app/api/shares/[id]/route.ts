import type { Project } from "../../../model";
import {
  BlobStorageUnavailableError,
  getStoredShare,
  updateStoredShare,
} from "../../../../lib/vercel-blob-store";

function validProject(value: unknown): value is Project {
  if (!value || typeof value !== "object") return false;
  const project = value as { name?: unknown; tasks?: unknown };
  return typeof project.name === "string" && project.name.trim().length > 0 && Array.isArray(project.tasks);
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const shared = await getStoredShare(id);
    if (!shared) return Response.json({ error: "Shared project not found." }, { status: 404 });
    return Response.json(shared, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load shared project", error);
    const message = error instanceof Error ? error.message : "The shared project is temporarily unavailable.";
    return Response.json(
      { error: message },
      { status: error instanceof BlobStorageUnavailableError ? 503 : 500 },
    );
  }
}

export async function PUT(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const payload = (await request.json()) as { project?: unknown };
    if (!validProject(payload.project)) {
      return Response.json({ error: "A valid project is required." }, { status: 400 });
    }

    const result = await updateStoredShare(id, payload.project, request.headers.get("x-share-edit-token"));
    if (!result.ok) {
      const status = result.reason === "missing" ? 404 : 403;
      const error = result.reason === "missing" ? "Shared project not found." : "This browser does not have permission to update this manager link.";
      return Response.json({ error }, { status });
    }

    return Response.json(
      { updatedAt: result.updatedAt },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    console.error("Unable to update shared project", error);
    const message = error instanceof Error ? error.message : "The shared project could not be updated.";
    return Response.json(
      { error: message },
      { status: error instanceof BlobStorageUnavailableError ? 503 : 500 },
    );
  }
}
