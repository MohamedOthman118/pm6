import type { Project } from "../../model";
import { BlobStorageUnavailableError, createStoredShare } from "../../../lib/vercel-blob-store";

function validProject(value: unknown): value is Project {
  if (!value || typeof value !== "object") return false;
  const project = value as { name?: unknown; tasks?: unknown };
  return typeof project.name === "string" && project.name.trim().length > 0 && Array.isArray(project.tasks);
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as { project?: unknown };
    if (!validProject(payload.project)) {
      return Response.json({ error: "A valid project is required." }, { status: 400 });
    }

    const result = await createStoredShare(payload.project);
    return Response.json(result, {
      status: 201,
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("Unable to create shared project", error);
    const message = error instanceof Error ? error.message : "The manager link could not be created right now.";
    return Response.json(
      { error: message },
      { status: error instanceof BlobStorageUnavailableError ? 503 : 500 },
    );
  }
}
