import { BlobStorageUnavailableError, getTeamImage } from "../../../../lib/vercel-blob-store";

export async function GET(_request: Request, context: { params: Promise<{ key: string[] }> }) {
  try {
    const { key } = await context.params;
    const objectKey = key.join("/");
    if (!objectKey.startsWith("team/")) return new Response("Not found", { status: 404 });

    const object = await getTeamImage(objectKey);
    if (!object || object.statusCode !== 200 || !object.stream) {
      return new Response("Not found", { status: 404 });
    }

    return new Response(object.stream, {
      headers: {
        "Content-Type": object.blob.contentType || "application/octet-stream",
        "Cache-Control": "public, max-age=86400, stale-while-revalidate=604800",
        "X-Content-Type-Options": "nosniff",
        ETag: object.blob.etag,
      },
    });
  } catch (error) {
    console.error("Unable to load team photo", error);
    return new Response(
      error instanceof BlobStorageUnavailableError ? error.message : "The team photo is temporarily unavailable.",
      { status: error instanceof BlobStorageUnavailableError ? 503 : 500 },
    );
  }
}
