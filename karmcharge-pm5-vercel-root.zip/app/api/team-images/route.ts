import { BlobStorageUnavailableError, storeTeamImage } from "../../../lib/vercel-blob-store";

const MAX_IMAGE_BYTES = 2_000_000;
const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File) || !ALLOWED_IMAGE_TYPES.has(file.type)) {
      return Response.json({ error: "Choose a JPG, PNG, or WebP image." }, { status: 400 });
    }
    if (file.size > MAX_IMAGE_BYTES) {
      return Response.json({ error: "Team photos must be smaller than 2 MB." }, { status: 413 });
    }

    const pathname = await storeTeamImage(file);
    return Response.json({ url: `/api/team-images/${pathname}` }, { status: 201 });
  } catch (error) {
    console.error("Unable to upload team photo", error);
    const message = error instanceof Error ? error.message : "The team photo could not be uploaded.";
    return Response.json(
      { error: message },
      { status: error instanceof BlobStorageUnavailableError ? 503 : 500 },
    );
  }
}
