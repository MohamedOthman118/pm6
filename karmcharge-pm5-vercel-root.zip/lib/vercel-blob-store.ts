import { get, put } from "@vercel/blob";

import type { Project } from "../app/model";

const MAX_PROJECT_BYTES = 500_000;
const SHARE_ID_RE = /^[a-f0-9]{32}$/;

export class BlobStorageUnavailableError extends Error {
  constructor() {
    super("Vercel Blob is not connected. Create a Blob store for this project in Vercel Storage and redeploy.");
    this.name = "BlobStorageUnavailableError";
  }
}

type StoredShare = {
  project: Project;
  editToken: string;
  updatedAt: string;
};

function ensureBlobToken() {
  if (!process.env.BLOB_READ_WRITE_TOKEN) throw new BlobStorageUnavailableError();
}

function sharePath(id: string) {
  if (!SHARE_ID_RE.test(id)) return null;
  return `shares/${id}.json`;
}

function stripPrivateShareFields(project: Project): Project {
  const { shareToken: _shareToken, ...safeProject } = project;
  return safeProject;
}

function serializedProject(project: Project) {
  const safeProject = stripPrivateShareFields(project);
  const projectJson = JSON.stringify(safeProject);
  if (new TextEncoder().encode(projectJson).length > MAX_PROJECT_BYTES) {
    throw new Error("This project is too large to share.");
  }
  return safeProject;
}

async function readStoredShare(id: string): Promise<StoredShare | null> {
  ensureBlobToken();
  const pathname = sharePath(id);
  if (!pathname) return null;

  const result = await get(pathname, { access: "private" });
  if (!result || result.statusCode !== 200 || !result.stream) return null;

  try {
    const record = (await new Response(result.stream).json()) as StoredShare;
    if (!record?.project || !record?.editToken || !record?.updatedAt) return null;
    return record;
  } catch {
    return null;
  }
}

export async function createStoredShare(project: Project) {
  ensureBlobToken();
  const id = crypto.randomUUID().replaceAll("-", "");
  const editToken = `${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().replaceAll("-", "")}`;
  const updatedAt = new Date().toISOString();
  const safeProject = serializedProject(project);

  await put(
    `shares/${id}.json`,
    JSON.stringify({ project: { ...safeProject, shareId: id }, editToken, updatedAt } satisfies StoredShare),
    {
      access: "private",
      addRandomSuffix: false,
      allowOverwrite: false,
      contentType: "application/json",
      cacheControlMaxAge: 60,
    },
  );

  return { shareId: id, editToken, updatedAt };
}

export async function getStoredShare(id: string) {
  const record = await readStoredShare(id);
  if (!record) return null;
  return { project: record.project, updatedAt: record.updatedAt };
}

export async function updateStoredShare(id: string, project: Project, editToken: string | null) {
  ensureBlobToken();
  const pathname = sharePath(id);
  if (!pathname || !editToken) return { ok: false as const, reason: "forbidden" as const };

  const current = await readStoredShare(id);
  if (!current) return { ok: false as const, reason: "missing" as const };
  if (current.editToken !== editToken) return { ok: false as const, reason: "forbidden" as const };

  const updatedAt = new Date().toISOString();
  const safeProject = serializedProject(project);
  await put(
    pathname,
    JSON.stringify({ project: { ...safeProject, shareId: id }, editToken: current.editToken, updatedAt } satisfies StoredShare),
    {
      access: "private",
      addRandomSuffix: false,
      allowOverwrite: true,
      contentType: "application/json",
      cacheControlMaxAge: 60,
    },
  );

  return { ok: true as const, updatedAt };
}

export async function storeTeamImage(file: File) {
  ensureBlobToken();
  const extension = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  const pathname = `team/${crypto.randomUUID()}.${extension}`;
  await put(pathname, file, {
    access: "private",
    addRandomSuffix: false,
    allowOverwrite: false,
    contentType: file.type,
    cacheControlMaxAge: 86400,
  });
  return pathname;
}

export async function getTeamImage(pathname: string) {
  ensureBlobToken();
  if (!pathname.startsWith("team/")) return null;
  return get(pathname, { access: "private" });
}
